﻿/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 爱玩游戏的小胖子
 * UI: UI/module/PetUI/PetRafflePanel.ui
 * TIME: 2024.05.25-14.47.29
 */
 
@UIBind('UI/module/PetUI/PetRafflePanel.ui')
export default class PetRafflePanel_Generate extends UIScript {
		private mCloseButton_Internal: mw.Button
	public get mCloseButton(): mw.Button {
		if(!this.mCloseButton_Internal&&this.uiWidgetBase) {
			this.mCloseButton_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mCloseButton') as mw.Button
		}
		return this.mCloseButton_Internal
	}
	private mPetIcon1_Internal: mw.Image
	public get mPetIcon1(): mw.Image {
		if(!this.mPetIcon1_Internal&&this.uiWidgetBase) {
			this.mPetIcon1_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas1/mPetIcon1') as mw.Image
		}
		return this.mPetIcon1_Internal
	}
	private mSelectImage1_Internal: mw.Image
	public get mSelectImage1(): mw.Image {
		if(!this.mSelectImage1_Internal&&this.uiWidgetBase) {
			this.mSelectImage1_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas1/mSelectImage1') as mw.Image
		}
		return this.mSelectImage1_Internal
	}
	private mPetIcon2_Internal: mw.Image
	public get mPetIcon2(): mw.Image {
		if(!this.mPetIcon2_Internal&&this.uiWidgetBase) {
			this.mPetIcon2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas2/mPetIcon2') as mw.Image
		}
		return this.mPetIcon2_Internal
	}
	private mSelectImage2_Internal: mw.Image
	public get mSelectImage2(): mw.Image {
		if(!this.mSelectImage2_Internal&&this.uiWidgetBase) {
			this.mSelectImage2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas2/mSelectImage2') as mw.Image
		}
		return this.mSelectImage2_Internal
	}
	private mPetIcon3_Internal: mw.Image
	public get mPetIcon3(): mw.Image {
		if(!this.mPetIcon3_Internal&&this.uiWidgetBase) {
			this.mPetIcon3_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas3/mPetIcon3') as mw.Image
		}
		return this.mPetIcon3_Internal
	}
	private mSelectImage3_Internal: mw.Image
	public get mSelectImage3(): mw.Image {
		if(!this.mSelectImage3_Internal&&this.uiWidgetBase) {
			this.mSelectImage3_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas3/mSelectImage3') as mw.Image
		}
		return this.mSelectImage3_Internal
	}
	private mPetIcon4_Internal: mw.Image
	public get mPetIcon4(): mw.Image {
		if(!this.mPetIcon4_Internal&&this.uiWidgetBase) {
			this.mPetIcon4_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas4/mPetIcon4') as mw.Image
		}
		return this.mPetIcon4_Internal
	}
	private mSelectImage4_Internal: mw.Image
	public get mSelectImage4(): mw.Image {
		if(!this.mSelectImage4_Internal&&this.uiWidgetBase) {
			this.mSelectImage4_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas4/mSelectImage4') as mw.Image
		}
		return this.mSelectImage4_Internal
	}
	private mPetIcon5_Internal: mw.Image
	public get mPetIcon5(): mw.Image {
		if(!this.mPetIcon5_Internal&&this.uiWidgetBase) {
			this.mPetIcon5_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas5/mPetIcon5') as mw.Image
		}
		return this.mPetIcon5_Internal
	}
	private mSelectImage5_Internal: mw.Image
	public get mSelectImage5(): mw.Image {
		if(!this.mSelectImage5_Internal&&this.uiWidgetBase) {
			this.mSelectImage5_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas5/mSelectImage5') as mw.Image
		}
		return this.mSelectImage5_Internal
	}
	private mPetIcon6_Internal: mw.Image
	public get mPetIcon6(): mw.Image {
		if(!this.mPetIcon6_Internal&&this.uiWidgetBase) {
			this.mPetIcon6_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas6/mPetIcon6') as mw.Image
		}
		return this.mPetIcon6_Internal
	}
	private mSelectImage6_Internal: mw.Image
	public get mSelectImage6(): mw.Image {
		if(!this.mSelectImage6_Internal&&this.uiWidgetBase) {
			this.mSelectImage6_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas6/mSelectImage6') as mw.Image
		}
		return this.mSelectImage6_Internal
	}
	private mPetIcon7_Internal: mw.Image
	public get mPetIcon7(): mw.Image {
		if(!this.mPetIcon7_Internal&&this.uiWidgetBase) {
			this.mPetIcon7_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas7/mPetIcon7') as mw.Image
		}
		return this.mPetIcon7_Internal
	}
	private mSelectImage7_Internal: mw.Image
	public get mSelectImage7(): mw.Image {
		if(!this.mSelectImage7_Internal&&this.uiWidgetBase) {
			this.mSelectImage7_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas7/mSelectImage7') as mw.Image
		}
		return this.mSelectImage7_Internal
	}
	private mPetIcon8_Internal: mw.Image
	public get mPetIcon8(): mw.Image {
		if(!this.mPetIcon8_Internal&&this.uiWidgetBase) {
			this.mPetIcon8_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas8/mPetIcon8') as mw.Image
		}
		return this.mPetIcon8_Internal
	}
	private mSelectImage8_Internal: mw.Image
	public get mSelectImage8(): mw.Image {
		if(!this.mSelectImage8_Internal&&this.uiWidgetBase) {
			this.mSelectImage8_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas8/mSelectImage8') as mw.Image
		}
		return this.mSelectImage8_Internal
	}
	private mPetIcon9_Internal: mw.Image
	public get mPetIcon9(): mw.Image {
		if(!this.mPetIcon9_Internal&&this.uiWidgetBase) {
			this.mPetIcon9_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas9/mPetIcon9') as mw.Image
		}
		return this.mPetIcon9_Internal
	}
	private mSelectImage9_Internal: mw.Image
	public get mSelectImage9(): mw.Image {
		if(!this.mSelectImage9_Internal&&this.uiWidgetBase) {
			this.mSelectImage9_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas9/mSelectImage9') as mw.Image
		}
		return this.mSelectImage9_Internal
	}
	private mPetIcon10_Internal: mw.Image
	public get mPetIcon10(): mw.Image {
		if(!this.mPetIcon10_Internal&&this.uiWidgetBase) {
			this.mPetIcon10_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas10/mPetIcon10') as mw.Image
		}
		return this.mPetIcon10_Internal
	}
	private mSelectImage10_Internal: mw.Image
	public get mSelectImage10(): mw.Image {
		if(!this.mSelectImage10_Internal&&this.uiWidgetBase) {
			this.mSelectImage10_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas10/mSelectImage10') as mw.Image
		}
		return this.mSelectImage10_Internal
	}
	private mPetIcon11_Internal: mw.Image
	public get mPetIcon11(): mw.Image {
		if(!this.mPetIcon11_Internal&&this.uiWidgetBase) {
			this.mPetIcon11_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas11/mPetIcon11') as mw.Image
		}
		return this.mPetIcon11_Internal
	}
	private mSelectImage11_Internal: mw.Image
	public get mSelectImage11(): mw.Image {
		if(!this.mSelectImage11_Internal&&this.uiWidgetBase) {
			this.mSelectImage11_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas11/mSelectImage11') as mw.Image
		}
		return this.mSelectImage11_Internal
	}
	private mPetIcon12_Internal: mw.Image
	public get mPetIcon12(): mw.Image {
		if(!this.mPetIcon12_Internal&&this.uiWidgetBase) {
			this.mPetIcon12_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas12/mPetIcon12') as mw.Image
		}
		return this.mPetIcon12_Internal
	}
	private mSelectImage12_Internal: mw.Image
	public get mSelectImage12(): mw.Image {
		if(!this.mSelectImage12_Internal&&this.uiWidgetBase) {
			this.mSelectImage12_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/Canvas_1/Canvas12/mSelectImage12') as mw.Image
		}
		return this.mSelectImage12_Internal
	}
	private mRaffleButton_Internal: mw.Button
	public get mRaffleButton(): mw.Button {
		if(!this.mRaffleButton_Internal&&this.uiWidgetBase) {
			this.mRaffleButton_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mRaffleButton') as mw.Button
		}
		return this.mRaffleButton_Internal
	}
	private mRaffleText_Internal: mw.TextBlock
	public get mRaffleText(): mw.TextBlock {
		if(!this.mRaffleText_Internal&&this.uiWidgetBase) {
			this.mRaffleText_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mRaffleButton/mRaffleText') as mw.TextBlock
		}
		return this.mRaffleText_Internal
	}
	private mPetButton_Internal: mw.Button
	public get mPetButton(): mw.Button {
		if(!this.mPetButton_Internal&&this.uiWidgetBase) {
			this.mPetButton_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mPetButton') as mw.Button
		}
		return this.mPetButton_Internal
	}
	private mGetCanvas_Internal: mw.Canvas
	public get mGetCanvas(): mw.Canvas {
		if(!this.mGetCanvas_Internal&&this.uiWidgetBase) {
			this.mGetCanvas_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mGetCanvas') as mw.Canvas
		}
		return this.mGetCanvas_Internal
	}
	private mCloseGetButton_Internal: mw.Button
	public get mCloseGetButton(): mw.Button {
		if(!this.mCloseGetButton_Internal&&this.uiWidgetBase) {
			this.mCloseGetButton_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mGetCanvas/mCloseGetButton') as mw.Button
		}
		return this.mCloseGetButton_Internal
	}
	private mGetImage_Internal: mw.Image
	public get mGetImage(): mw.Image {
		if(!this.mGetImage_Internal&&this.uiWidgetBase) {
			this.mGetImage_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mGetCanvas/Canvas_3/mGetImage') as mw.Image
		}
		return this.mGetImage_Internal
	}


	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = mw.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		//按钮添加点击
		
		this.mCloseButton.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mCloseButton");
		});
		this.mCloseButton.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mRaffleButton.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mRaffleButton");
		});
		this.mRaffleButton.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mPetButton.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mPetButton");
		});
		this.mPetButton.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mCloseGetButton.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mCloseGetButton");
		});
		this.mCloseGetButton.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		//按钮多语言
		
		//文本多语言
		
		this.initLanguage(this.mRaffleText)
		
	
		//文本多语言
		
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas/mPetButton/RaffleText") as any);
		
	
	}
	
	/*初始化多语言*/
	private initLanguage(ui: mw.StaleButton | mw.TextBlock) {
        let call = mw.UIScript.getBehavior("lan");
        if (call && ui) {
            call(ui);
        }
    }

	protected onShow(...params: any[]): void {};

	/*显示panel*/
    public show(...param): void {
		mw.UIService.showUI(this, this.layer, ...param);
	}

	/*隐藏panel*/
    public hide(): void {
		mw.UIService.hideUI(this);
	}
 }
 