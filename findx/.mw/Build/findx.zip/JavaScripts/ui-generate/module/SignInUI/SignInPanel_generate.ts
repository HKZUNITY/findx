﻿/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 爱玩游戏的小胖子
 * UI: UI/module/SignInUI/SignInPanel.ui
 * TIME: 2024.05.25-14.47.29
 */
 
@UIBind('UI/module/SignInUI/SignInPanel.ui')
export default class SignInPanel_Generate extends UIScript {
		private mSignInBtn1_Internal: mw.Button
	public get mSignInBtn1(): mw.Button {
		if(!this.mSignInBtn1_Internal&&this.uiWidgetBase) {
			this.mSignInBtn1_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/Canvas/Canvas_1/mSignInBtn1') as mw.Button
		}
		return this.mSignInBtn1_Internal
	}
	private mSignInTxt1_Internal: mw.TextBlock
	public get mSignInTxt1(): mw.TextBlock {
		if(!this.mSignInTxt1_Internal&&this.uiWidgetBase) {
			this.mSignInTxt1_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/Canvas/Canvas_1/mSignInBtn1/mSignInTxt1') as mw.TextBlock
		}
		return this.mSignInTxt1_Internal
	}
	private mReawrdImage1_Internal: mw.Image
	public get mReawrdImage1(): mw.Image {
		if(!this.mReawrdImage1_Internal&&this.uiWidgetBase) {
			this.mReawrdImage1_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/Canvas/Canvas_1/mReawrdImage1') as mw.Image
		}
		return this.mReawrdImage1_Internal
	}
	private mSignInBtn2_Internal: mw.Button
	public get mSignInBtn2(): mw.Button {
		if(!this.mSignInBtn2_Internal&&this.uiWidgetBase) {
			this.mSignInBtn2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/Canvas/Canvas_2/mSignInBtn2') as mw.Button
		}
		return this.mSignInBtn2_Internal
	}
	private mSignInTxt2_Internal: mw.TextBlock
	public get mSignInTxt2(): mw.TextBlock {
		if(!this.mSignInTxt2_Internal&&this.uiWidgetBase) {
			this.mSignInTxt2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/Canvas/Canvas_2/mSignInBtn2/mSignInTxt2') as mw.TextBlock
		}
		return this.mSignInTxt2_Internal
	}
	private mReawrdImage2_Internal: mw.Image
	public get mReawrdImage2(): mw.Image {
		if(!this.mReawrdImage2_Internal&&this.uiWidgetBase) {
			this.mReawrdImage2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/Canvas/Canvas_2/mReawrdImage2') as mw.Image
		}
		return this.mReawrdImage2_Internal
	}
	private mSignInBtn3_Internal: mw.Button
	public get mSignInBtn3(): mw.Button {
		if(!this.mSignInBtn3_Internal&&this.uiWidgetBase) {
			this.mSignInBtn3_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/Canvas/Canvas_3/mSignInBtn3') as mw.Button
		}
		return this.mSignInBtn3_Internal
	}
	private mSignInTxt3_Internal: mw.TextBlock
	public get mSignInTxt3(): mw.TextBlock {
		if(!this.mSignInTxt3_Internal&&this.uiWidgetBase) {
			this.mSignInTxt3_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/Canvas/Canvas_3/mSignInBtn3/mSignInTxt3') as mw.TextBlock
		}
		return this.mSignInTxt3_Internal
	}
	private mReawrdImage3_Internal: mw.Image
	public get mReawrdImage3(): mw.Image {
		if(!this.mReawrdImage3_Internal&&this.uiWidgetBase) {
			this.mReawrdImage3_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/Canvas/Canvas_3/mReawrdImage3') as mw.Image
		}
		return this.mReawrdImage3_Internal
	}
	private mSignInBtn4_Internal: mw.Button
	public get mSignInBtn4(): mw.Button {
		if(!this.mSignInBtn4_Internal&&this.uiWidgetBase) {
			this.mSignInBtn4_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/Canvas/Canvas_4/mSignInBtn4') as mw.Button
		}
		return this.mSignInBtn4_Internal
	}
	private mSignInTxt4_Internal: mw.TextBlock
	public get mSignInTxt4(): mw.TextBlock {
		if(!this.mSignInTxt4_Internal&&this.uiWidgetBase) {
			this.mSignInTxt4_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/Canvas/Canvas_4/mSignInBtn4/mSignInTxt4') as mw.TextBlock
		}
		return this.mSignInTxt4_Internal
	}
	private mReawrdImage4_Internal: mw.Image
	public get mReawrdImage4(): mw.Image {
		if(!this.mReawrdImage4_Internal&&this.uiWidgetBase) {
			this.mReawrdImage4_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/Canvas/Canvas_4/mReawrdImage4') as mw.Image
		}
		return this.mReawrdImage4_Internal
	}
	private mSignInBtn5_Internal: mw.Button
	public get mSignInBtn5(): mw.Button {
		if(!this.mSignInBtn5_Internal&&this.uiWidgetBase) {
			this.mSignInBtn5_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/Canvas/Canvas_5/mSignInBtn5') as mw.Button
		}
		return this.mSignInBtn5_Internal
	}
	private mSignInTxt5_Internal: mw.TextBlock
	public get mSignInTxt5(): mw.TextBlock {
		if(!this.mSignInTxt5_Internal&&this.uiWidgetBase) {
			this.mSignInTxt5_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/Canvas/Canvas_5/mSignInBtn5/mSignInTxt5') as mw.TextBlock
		}
		return this.mSignInTxt5_Internal
	}
	private mReawrdImage5_Internal: mw.Image
	public get mReawrdImage5(): mw.Image {
		if(!this.mReawrdImage5_Internal&&this.uiWidgetBase) {
			this.mReawrdImage5_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/Canvas/Canvas_5/mReawrdImage5') as mw.Image
		}
		return this.mReawrdImage5_Internal
	}
	private mSignInBtn6_Internal: mw.Button
	public get mSignInBtn6(): mw.Button {
		if(!this.mSignInBtn6_Internal&&this.uiWidgetBase) {
			this.mSignInBtn6_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/Canvas/Canvas_6/mSignInBtn6') as mw.Button
		}
		return this.mSignInBtn6_Internal
	}
	private mSignInTxt6_Internal: mw.TextBlock
	public get mSignInTxt6(): mw.TextBlock {
		if(!this.mSignInTxt6_Internal&&this.uiWidgetBase) {
			this.mSignInTxt6_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/Canvas/Canvas_6/mSignInBtn6/mSignInTxt6') as mw.TextBlock
		}
		return this.mSignInTxt6_Internal
	}
	private mReawrdImage6_Internal: mw.Image
	public get mReawrdImage6(): mw.Image {
		if(!this.mReawrdImage6_Internal&&this.uiWidgetBase) {
			this.mReawrdImage6_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/Canvas/Canvas_6/mReawrdImage6') as mw.Image
		}
		return this.mReawrdImage6_Internal
	}
	private mSignInBtn7_Internal: mw.Button
	public get mSignInBtn7(): mw.Button {
		if(!this.mSignInBtn7_Internal&&this.uiWidgetBase) {
			this.mSignInBtn7_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/Canvas/Canvas_7/mSignInBtn7') as mw.Button
		}
		return this.mSignInBtn7_Internal
	}
	private mSignInTxt7_Internal: mw.TextBlock
	public get mSignInTxt7(): mw.TextBlock {
		if(!this.mSignInTxt7_Internal&&this.uiWidgetBase) {
			this.mSignInTxt7_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/Canvas/Canvas_7/mSignInBtn7/mSignInTxt7') as mw.TextBlock
		}
		return this.mSignInTxt7_Internal
	}
	private mReawrdImage7_Internal: mw.Image
	public get mReawrdImage7(): mw.Image {
		if(!this.mReawrdImage7_Internal&&this.uiWidgetBase) {
			this.mReawrdImage7_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/Canvas/Canvas_7/mReawrdImage7') as mw.Image
		}
		return this.mReawrdImage7_Internal
	}
	private mCloseButton_Internal: mw.Button
	public get mCloseButton(): mw.Button {
		if(!this.mCloseButton_Internal&&this.uiWidgetBase) {
			this.mCloseButton_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/mCloseButton') as mw.Button
		}
		return this.mCloseButton_Internal
	}


	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = mw.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		//按钮添加点击
		
		this.mSignInBtn1.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mSignInBtn1");
		});
		this.mSignInBtn1.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mSignInBtn2.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mSignInBtn2");
		});
		this.mSignInBtn2.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mSignInBtn3.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mSignInBtn3");
		});
		this.mSignInBtn3.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mSignInBtn4.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mSignInBtn4");
		});
		this.mSignInBtn4.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mSignInBtn5.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mSignInBtn5");
		});
		this.mSignInBtn5.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mSignInBtn6.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mSignInBtn6");
		});
		this.mSignInBtn6.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mSignInBtn7.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mSignInBtn7");
		});
		this.mSignInBtn7.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mCloseButton.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mCloseButton");
		});
		this.mCloseButton.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		//按钮多语言
		
		//文本多语言
		
		this.initLanguage(this.mSignInTxt1)
		
	
		this.initLanguage(this.mSignInTxt2)
		
	
		this.initLanguage(this.mSignInTxt3)
		
	
		this.initLanguage(this.mSignInTxt4)
		
	
		this.initLanguage(this.mSignInTxt5)
		
	
		this.initLanguage(this.mSignInTxt6)
		
	
		this.initLanguage(this.mSignInTxt7)
		
	
		//文本多语言
		
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_1/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_1/TextBlock_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_1/TextBlock_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_2/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_2/TextBlock_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_2/TextBlock_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_3/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_3/TextBlock_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_3/TextBlock_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_4/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_4/TextBlock_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_4/TextBlock_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_5/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_5/TextBlock_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_5/TextBlock_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_6/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_6/TextBlock_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_6/TextBlock_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_7/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_7/TextBlock_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_7/TextBlock_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_7/TextBlock_1_2") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/TextBlock_3") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/TextBlock_4") as any);
		
	
	}
	
	/*初始化多语言*/
	private initLanguage(ui: mw.StaleButton | mw.TextBlock) {
        let call = mw.UIScript.getBehavior("lan");
        if (call && ui) {
            call(ui);
        }
    }

	protected onShow(...params: any[]): void {};

	/*显示panel*/
    public show(...param): void {
		mw.UIService.showUI(this, this.layer, ...param);
	}

	/*隐藏panel*/
    public hide(): void {
		mw.UIService.hideUI(this);
	}
 }
 