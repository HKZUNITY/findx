﻿
/** 
 * AUTHOR: 爱玩游戏的小胖子
 * TIME: 2023.06.03-14.37.42
 */

import { GameConfig } from "../config/GameConfig";
import Test_Generate from "../ui-generate/common/Test_generate";

export default class Test extends Test_Generate {
	private player: Gameplay.Player = null;
	/**玩家身上的相机 */
	private camera: Gameplay.CameraSystem = null;
	/**拿到相机 */
	private get getCamera(): Gameplay.CameraSystem {
		if (this.camera == null) {
			this.camera = this.player.character.cameraSystem;
		}
		return this.camera;
	}
	/** 
	 * 构造UI文件成功后，在合适的时机最先初始化一次 
	 */
	protected async onStart() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = UI.UILayerMiddle;

		this.player = await Gameplay.asyncGetCurrentPlayer();
		this.setCameraTransform();
	}
	/**设置玩家摄像机偏移、旋转 */
	private setCameraTransform(): void {
		this.mWingBtn.onClicked.add(() => {
			let value = this.mWingInput.text.split('#');
			let wing = GameConfig.Wing.getElement(Number(value[0]));
			let posValue = value[1].split('|');
			wing.WingOffset = new Type.Vector(Number(posValue[0]), Number(posValue[1]), Number(posValue[2]));
			let rotValue = value[2].split('|');
			wing.WingRotation = new Type.Vector(Number(rotValue[0]), Number(rotValue[1]), Number(rotValue[2]));
			let scaValue = value[3].split('|');
			wing.WingScale = new Type.Vector(Number(scaValue[0]), Number(scaValue[1]), Number(scaValue[2]));
		});
	}

}
