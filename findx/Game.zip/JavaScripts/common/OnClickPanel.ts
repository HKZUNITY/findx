﻿
/** 
 * AUTHOR: 爱玩游戏的小胖子
 * TIME: 2023.05.31-17.50.28
 */

import Console from "../Tools/Console";
import { OnClickType } from "../const/Enum";
import GlobalData from "../const/GlobalData";
import { DanceModuleC } from "../module/DanceModule";
import HUDModuleC from "../module/HUDModule/HUDModuleC";
import OnClickPanel_Generate from "../ui-generate/common/OnClickPanel_generate";

export default class OnClickPanel extends OnClickPanel_Generate {
    private hudModuleC: HUDModuleC = null;
    private danceModuleC: DanceModuleC = null;

    private id: number = -1;
    private onClickType: number = -1;
    private offset: Type.Vector = new Type.Vector(0, 0, 0);
    private obj: Core.GameObject = null;

    /** 
     * 构造UI文件成功后，在合适的时机最先初始化一次 
     */
    protected onStart() {
        //设置能否每帧触发onUpdate
        this.canUpdate = false;
        this.layer = UI.UILayerMiddle;

        this.initData();
        this.bindButtons();
        this.registerActions();
        Console.error("[OnClickPanel-onStart]");
    }

    /**初始化数据 */
    private initData(): void {
        // this.offset = new Type.Vector(0, 0, 0);
        this.hudModuleC = ModuleManager.getInstance().getModule(HUDModuleC);
        this.danceModuleC = ModuleManager.getInstance().getModule(DanceModuleC);
    }

    /**按钮绑定 */
    private bindButtons(): void {
        this.mClickBtn.onClicked.add(this.onClickButtons.bind(this));
    }

    /**注册事件 */
    private registerActions(): void {
        this.hudModuleC.onJumpAction.add(() => {
            if (this.onClickType == OnClickType.Sit) {
                Events.dispatchToServer("Sit", false, this.id);
            }

            if (this.onClickType == OnClickType.Dance) {
                if (this.id == 7) {
                    this.danceModuleC.stopDance();
                    return;
                }
                Events.dispatchLocal("Dance", false, this.id);
            }
        });
    }

    private onClickButtons(): void {
        if (!this.id) return;
        Console.error("OnClickPanel-this.id = " + this.id);
        this.canUpdate = false;
        this.hide();
        if (this.id == -1) return;
        if (this.onClickType == OnClickType.Sit) {
            Console.error("[Sit] = " + this.id);
            Events.dispatchToServer("Sit", true, this.id);
            Events.dispatchLocal("achSit", 1);
        }
        else if (this.onClickType == OnClickType.Shake) {
            Console.error("[Shake] = " + this.id);
            this.hudModuleC.onMusicAction.call();
        }
        else if (this.onClickType == OnClickType.Dance) {
            Console.error("[Dance] = " + this.id);
            if (this.id == 7) {
                this.danceModuleC.startDance();
                return;
            }
            Events.dispatchLocal("Dance", true, this.id);
            Events.dispatchLocal("achDance", 1);
        }
    }

    /**显示NPC按钮 */
    public showBtn(id: number, obj: Core.GameObject, onClickType: OnClickType): void {
        this.id = id;
        this.onClickType = onClickType;
        this.canUpdate = true;
        this.obj = obj;
        let pos = InputUtil.projectWorldLocationToWidgetPosition(this.obj.worldLocation.add(this.offset), false).screenPosition;
        this.rootCanvas.position = pos.subtract(this.rootCanvas.size.multiply(0.5));
        this.rootCanvas.visibility = UI.SlateVisibility.SelfHitTestInvisible;
        this.show();
    }

    /**隐藏NPC按钮 */
    public hideBtn(): void {
        this.canUpdate = false;
        this.hide();
    }

    protected onShow(...params: any[]): void {
        Console.error("[OnClickPanel-onShow]");
        let imageGuid: string = "";
        if (this.onClickType == OnClickType.Sit) {
            imageGuid = GlobalData.sitIconGuid;
        }
        else if (this.onClickType == OnClickType.Shake) {
            imageGuid = GlobalData.shakeIconGuid;
        }
        else if (this.onClickType == OnClickType.Dance) {
            imageGuid = GlobalData.danceIconGuid;
        }
        this.mClickBtn.normalImageGuid = imageGuid;
        this.mClickBtn.pressedImageGuid = imageGuid;
        this.mClickBtn.disableImageGuid = imageGuid;
    }

    protected onHide(...params: any[]): void {
        Console.error("[OnClickPanel-onHide]");
    }

    /**
    * 每一帧调用
    * 通过canUpdate可以开启关闭调用
    * dt 两帧调用的时间差，毫秒
    */
    protected onUpdate(dt: number) {
        if (!this.obj) return;
        let pos: Type.Vector2 = Util.InputUtil.projectWorldLocationToWidgetPosition(this.obj.worldLocation.add(this.offset), false).screenPosition;
        this.rootCanvas.position = pos.subtract(this.rootCanvas.size.multiply(0.5));
    }
}
