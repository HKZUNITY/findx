﻿import Console from "../Tools/Console";
import { Utils } from "../Tools/utils";
import { FlyText } from "./FlyText";

export class ExplosiveCoins {
    private static _instance: ExplosiveCoins
    public static get instance() {
        if (ExplosiveCoins._instance == null) {
            ExplosiveCoins._instance = new ExplosiveCoins();
        }
        return ExplosiveCoins._instance;
    }
    private mapId: number = 0;
    private maxMapId: number = 10;
    private particles: Map<number, Gameplay.Particle>[] = [];
    private recycleParticles: Map<number, Gameplay.Particle> = new Map<number, Gameplay.Particle>();
    private player: Gameplay.Player = null;
    /**爆金币 */
    public explosiveCoins(fromVec: Type.Vector, coinCount: number = 1, coinNum: number = 10): void {
        // coinCount = Math.round(coinCount / coinNum);
        if (this.mapId >= this.maxMapId) this.mapId = 0;
        let mapId = this.mapId++;
        this.play3DSound(fromVec);
        for (let i = 0; i < coinNum; ++i) {
            this.startExplosiveCoins(fromVec, mapId);
        }
        TimeUtil.delaySecond(2).then(() => {
            this.particles[mapId].forEach((particle: Gameplay.Particle, effectId: number) => {
                let fromVec = particle.getWorldLocation();
                let toVec: Type.Vector = Type.Vector.zero;
                if (this.player == null) this.player = Gameplay.getCurrentPlayer();
                toVec = this.player.getWorldLocation();
                new Util.TweenUtil.Tween({ x: fromVec.x, y: fromVec.y, z: fromVec.z })
                    .to({ x: toVec.x, y: toVec.y, z: toVec.z }, 0.1 * 1000)
                    .onUpdate((pos) => {
                        particle.setWorldLocation(new Type.Vector(pos.x, pos.y, pos.z));
                    })
                    .start()
                    .onComplete(() => {
                        particle.stop();
                        this.recycleParticles.set(effectId, particle);
                        this.particles[mapId].delete(effectId);
                    });
            });
            TimeUtil.delaySecond(0.1).then(() => {
                let vec = this.player.getWorldLocation();
                FlyText.instance.showFlyText("+Exp " + coinCount, new Type.Vector(vec.x, vec.y, vec.z + 30), Type.LinearColor.green, Type.LinearColor.yellow);
            });
            this.play3DSound(this.player.getWorldLocation());
        });
    }

    private async startExplosiveCoins(fromVec: Type.Vector, mapId: number): Promise<void> {
        let effectId: number = 0;
        let particle: Gameplay.Particle = null;
        if (this.recycleParticles.size > 0) {
            effectId = this.recycleParticles.keys().next().value;
            particle = this.recycleParticles.get(effectId);
            this.recycleParticles.delete(effectId);
        }
        else {
            effectId = EffectService.getInstance().playEffectAtLocation("176198", fromVec, 0);
            particle = await EffectService.getInstance().getEffectGameObject(effectId);
        }
        particle.loop = true;
        particle.play();
        Console.error("[effectId] = " + effectId);
        Console.error("[particle.guid] = " + particle.guid);
        if (!particle || !effectId) return;

        let toVec = Utils.circularRandomCoordinates(fromVec, 400, 20);
        let moddleVec = new Type.Vector((fromVec.x + toVec.x) / 2, (fromVec.y + toVec.y) / 2, fromVec.z + Utils.getRandomInteger(150, 250));
        let points: Type.Vector[] = Utils.getCurvePointsInNum([fromVec, moddleVec, toVec], 10);
        for (let j = 0; j < points.length - 1; ++j) {
            await new Promise<void>((resolve: () => void) => {
                new Util.TweenUtil.Tween({ x: points[j].x, y: points[j].y, z: points[j].z })
                    .to({ x: points[j + 1].x, y: points[j + 1].y, z: points[j + 1].z }, 0.5 * 1000 / 10)
                    .onUpdate((pos) => {
                        particle.setWorldLocation(new Type.Vector(pos.x, pos.y, pos.z));
                    })
                    .start();
                setTimeout(() => {
                    return resolve();
                }, 0.5 * 1000 / 10);
            });
        }
        if (this.particles[mapId] == null) this.particles[mapId] = new Map<number, Gameplay.Particle>();
        this.particles[mapId].set(effectId, particle);
    }

    private play3DSound(fromVec: Type.Vector): void {
        let soundId = SoundService.getInstance().play3DSound("148629", fromVec);
        TimeUtil.delaySecond(0.5).then(() => {
            SoundService.getInstance().stop3DSound(soundId);
        });
    }
}