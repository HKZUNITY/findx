﻿import GlobalData from "../const/GlobalData";

@Core.Class
export default class AIPortal extends Core.Script {

    /** 当脚本被实例后，会在第一帧更新前调用此函数 */
    protected onStart(): void {
        if (Util.SystemUtil.isServer()) {
            (this.gameObject as Gameplay.Trigger).onEnter.add(async (go: Core.GameObject) => {
                if (GlobalData.aiGuids.includes(go.guid)) {
                    let npc = await Core.GameObject.asyncFind(go.guid) as Gameplay.NPC;
                    npc.setWorldLocation(new Type.Vector(-2614, -1403, 150));
                }
            });
        }
    }

    /**
     * 周期函数 每帧执行
     * 此函数执行需要将this.useUpdate赋值为true
     * @param dt 当前帧与上一帧的延迟 / 秒
     */
    protected onUpdate(dt: number): void {

    }

    /** 脚本被销毁时最后一帧执行完调用此函数 */
    protected onDestroy(): void {

    }
}