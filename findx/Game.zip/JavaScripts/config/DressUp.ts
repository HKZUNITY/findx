import { ConfigBase, IElementBase } from "./ConfigBase";
const EXCELDATA:Array<Array<any>> = [["id","DressUpType","DressUpGuid","WingOffset","WingRotation","WingScale","Speed","Annotation"],["","","","","","","",""],[1,1,"42804",new Type.Vector(0,0,0),new Type.Vector(0,0,90),new Type.Vector(1,1,1),800,null],[2,1,"42805",new Type.Vector(0,0,0),new Type.Vector(0,0,90),new Type.Vector(1,1,1),900,null],[3,0,null,null,null,null,0,null],[4,0,null,null,null,null,0,null],[5,0,null,null,null,null,0,null],[6,2,"4399",new Type.Vector(0,0,0),new Type.Vector(0,0,0),new Type.Vector(1,1,1),460,null],[7,2,"151527",new Type.Vector(0,0,0),new Type.Vector(0,0,0),new Type.Vector(1,1,1),470,null]];
export interface IDressUpElement extends IElementBase{
 	/**唯一ID*/
	id:number
	/**装扮类型
1：翅膀--飞行
2：拖尾--增加移速*/
	DressUpType:number
	/**装扮的guid*/
	DressUpGuid:string
	/**偏移*/
	WingOffset:Type.Vector
	/**旋转*/
	WingRotation:Type.Vector
	/**缩放*/
	WingScale:Type.Vector
	/**飞行速度|移动速度*/
	Speed:number
	/**注释*/
	Annotation:string
 } 
export class DressUpConfig extends ConfigBase<IDressUpElement>{
	constructor(){
		super(EXCELDATA);
	}

}