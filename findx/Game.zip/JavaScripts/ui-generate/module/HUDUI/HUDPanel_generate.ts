﻿/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 爱玩游戏的小胖子
 * UI: UI/module/HUDUI/HUDPanel.ui
 * TIME: 2023.08.25-23.42.25
 */
 
@UI.UICallOnly('UI/module/HUDUI/HUDPanel.ui')
export default class HUDPanel_Generate extends UI.UIBehavior {
	@UI.UIMarkPath('RootCanvas/MainCanvas/mJoystick')
    public mJoystick: UI.VirtualJoystickPanel=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mTouchPad')
    public mTouchPad: UI.TouchPad=undefined;
    @UI.UIMarkPath('RootCanvas/RightDownCanvas/mFlyCanvas')
    public mFlyCanvas: UI.Canvas=undefined;
    @UI.UIMarkPath('RootCanvas/RightDownCanvas/mFlyCanvas/mFlyMaskBtn')
    public mFlyMaskBtn: UI.MaskButton=undefined;
    @UI.UIMarkPath('RootCanvas/RightDownCanvas/mFlyCanvas/mFlyText')
    public mFlyText: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/RightDownCanvas/mJumpCanvas')
    public mJumpCanvas: UI.Canvas=undefined;
    @UI.UIMarkPath('RootCanvas/RightDownCanvas/mJumpCanvas/mJumpBtn')
    public mJumpBtn: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/RightDownCanvas/mAttackCanvas')
    public mAttackCanvas: UI.Canvas=undefined;
    @UI.UIMarkPath('RootCanvas/RightDownCanvas/mAttackCanvas/mAttackMaskBtn')
    public mAttackMaskBtn: UI.MaskButton=undefined;
    @UI.UIMarkPath('RootCanvas/RightDownCanvas/mAttackCanvas/mCDTxt')
    public mCDTxt: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/RightTopCanvas/ClockCanvas/mTimeText')
    public mTimeText: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/RightTopCanvas/RaffleCanvas/mRaffleButton')
    public mRaffleButton: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/RightTopCanvas/AdsCanvas/mAchButton')
    public mAchButton: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/RightTopCanvas/AchCanvas/mAdsButton')
    public mAdsButton: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/RightTopCanvas/SignInCanvas/mSignInBtn')
    public mSignInBtn: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/RightTopCanvas/RankCanvas/mRankBtn')
    public mRankBtn: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/RightTopCanvas/MusicCanvas/mMusicBtn')
    public mMusicBtn: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/RightTopCanvas/LevelCanvas/mLevelBtn')
    public mLevelBtn: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/RightTopCanvas/ShopCanvas/mShopBtn')
    public mShopBtn: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/RightTopCanvas/HomeCanvas/mHomeBtn')
    public mHomeBtn: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/mMusicCanvas')
    public mMusicCanvas: UI.Canvas=undefined;
    @UI.UIMarkPath('RootCanvas/mMusicCanvas/mCloseMusicBtn')
    public mCloseMusicBtn: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/mMusicCanvas/Canvas/mMusicText')
    public mMusicText: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/mMusicCanvas/Canvas/mLeftMusicBtn')
    public mLeftMusicBtn: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/mMusicCanvas/Canvas/mOnOffMusicBtn')
    public mOnOffMusicBtn: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/mMusicCanvas/Canvas/mRightMusicBtn')
    public mRightMusicBtn: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MiddleBottomCanvas/mBeFlyingText')
    public mBeFlyingText: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MiddleBottomCanvas/mExpProgressBar')
    public mExpProgressBar: UI.ProgressBar=undefined;
    @UI.UIMarkPath('RootCanvas/LeftCanvas/mHpText')
    public mHpText: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/LeftCanvas/mAttackText')
    public mAttackText: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/LeftCanvas/mMoveSpeedText')
    public mMoveSpeedText: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/LeftCanvas/mFlySpeedText')
    public mFlySpeedText: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/LeftCanvas/mJumpHeightText')
    public mJumpHeightText: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/LeftCanvas/mPetButton')
    public mPetButton: UI.Button=undefined;
    

	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = UI.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		//按钮添加点击
		
		this.mJumpBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mJumpBtn");
		});
		this.mJumpBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mRaffleButton.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mRaffleButton");
		});
		this.mRaffleButton.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mAchButton.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mAchButton");
		});
		this.mAchButton.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mAdsButton.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mAdsButton");
		});
		this.mAdsButton.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mSignInBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mSignInBtn");
		});
		this.mSignInBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mRankBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mRankBtn");
		});
		this.mRankBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mMusicBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mMusicBtn");
		});
		this.mMusicBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mLevelBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mLevelBtn");
		});
		this.mLevelBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mShopBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mShopBtn");
		});
		this.mShopBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mHomeBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mHomeBtn");
		});
		this.mHomeBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mCloseMusicBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mCloseMusicBtn");
		});
		this.mCloseMusicBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mLeftMusicBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mLeftMusicBtn");
		});
		this.mLeftMusicBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mOnOffMusicBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mOnOffMusicBtn");
		});
		this.mOnOffMusicBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mRightMusicBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mRightMusicBtn");
		});
		this.mRightMusicBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mPetButton.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mPetButton");
		});
		this.mPetButton.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		//按钮多语言
		
		//文本多语言
		
		this.initLanguage(this.mFlyText)
		
	
		this.initLanguage(this.mCDTxt)
		
	
		this.initLanguage(this.mTimeText)
		
	
		this.initLanguage(this.mMusicText)
		
	
		this.initLanguage(this.mBeFlyingText)
		
	
		this.initLanguage(this.mHpText)
		
	
		this.initLanguage(this.mAttackText)
		
	
		this.initLanguage(this.mMoveSpeedText)
		
	
		this.initLanguage(this.mFlySpeedText)
		
	
		this.initLanguage(this.mJumpHeightText)
		
	
		//文本多语言
		
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/RightTopCanvas/RaffleCanvas/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/RightTopCanvas/AdsCanvas/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/RightTopCanvas/AchCanvas/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/RightTopCanvas/SignInCanvas/TextBlock_6") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/RightTopCanvas/RankCanvas/TextBlock_5") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/RightTopCanvas/MusicCanvas/TextBlock_4") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/RightTopCanvas/LevelCanvas/TextBlock_3") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/RightTopCanvas/ShopCanvas/TextBlock_2") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/RightTopCanvas/HomeCanvas/TextBlock_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MiddleBottomCanvas/TextBlock_8") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/LeftCanvas/mPetButton/TextBlock_7") as any);
		
	
	}
	
	/*初始化多语言*/
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehavior.getBehavior("lan");
        if (call && ui) {
            call(ui);
        }
    }

	protected onShow(...params: any[]): void {};

	/*显示panel*/
    public show(...param): void {
		UI.UIManager.instance.showUI(this, this.layer, ...param);
	}

	/*隐藏panel*/
    public hide(): void {
		UI.UIManager.instance.hideUI(this);
	}
 }
 