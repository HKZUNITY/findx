﻿/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 爱玩游戏的小胖子
 * UI: UI/module/NPCModule/NPCBar.ui
 * TIME: 2023.08.25-23.42.25
 */
 
@UI.UICallOnly('UI/module/NPCModule/NPCBar.ui')
export default class NPCBar_Generate extends UI.UIBehavior {
	@UI.UIMarkPath('RootCanvas/Canvas/mProgressBar')
    public mProgressBar: UI.ProgressBar=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/mHpTextBlock')
    public mHpTextBlock: UI.TextBlock=undefined;
    

	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = UI.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		//按钮添加点击
		
		//按钮多语言
		
		//文本多语言
		
		this.initLanguage(this.mHpTextBlock)
		
	
		//文本多语言
		
	}
	
	/*初始化多语言*/
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehavior.getBehavior("lan");
        if (call && ui) {
            call(ui);
        }
    }

	protected onShow(...params: any[]): void {};

	/*显示panel*/
    public show(...param): void {
		UI.UIManager.instance.showUI(this, this.layer, ...param);
	}

	/*隐藏panel*/
    public hide(): void {
		UI.UIManager.instance.hideUI(this);
	}
 }
 