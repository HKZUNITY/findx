﻿/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 爱玩游戏的小胖子
 * UI: UI/module/ShopUI/WingItem.ui
 * TIME: 2023.08.25-23.42.26
 */
 
@UI.UICallOnly('UI/module/ShopUI/WingItem.ui')
export default class WingItem_Generate extends UI.UIBehavior {
	@UI.UIMarkPath('RootCanvas/mCanvas/mSelectImg')
    public mSelectImg: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/mCanvas/mIAAImg')
    public mIAAImg: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/mCanvas/mIconBtn')
    public mIconBtn: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/mCanvas')
    public mCanvas: UI.Canvas=undefined;
    

	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = UI.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		//按钮添加点击
		
		this.mIconBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mIconBtn");
		});
		this.mIconBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		//按钮多语言
		
		//文本多语言
		
		//文本多语言
		
	}
	
	/*初始化多语言*/
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehavior.getBehavior("lan");
        if (call && ui) {
            call(ui);
        }
    }

	protected onShow(...params: any[]): void {};

	/*显示panel*/
    public show(...param): void {
		UI.UIManager.instance.showUI(this, this.layer, ...param);
	}

	/*隐藏panel*/
    public hide(): void {
		UI.UIManager.instance.hideUI(this);
	}
 }
 