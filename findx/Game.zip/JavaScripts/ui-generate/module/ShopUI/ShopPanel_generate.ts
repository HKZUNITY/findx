﻿/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 爱玩游戏的小胖子
 * UI: UI/module/ShopUI/ShopPanel.ui
 * TIME: 2023.08.25-23.42.26
 */
 
@UI.UICallOnly('UI/module/ShopUI/ShopPanel.ui')
export default class ShopPanel_Generate extends UI.UIBehavior {
	@UI.UIMarkPath('RootCanvas/MainCanvas/mLeftCanvas/ShopCanvas/ShopCanvas_1/mShopBtn1')
    public mShopBtn1: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mLeftCanvas/ShopCanvas/ShopCanvas_2/mShopBtn2')
    public mShopBtn2: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mLeftCanvas/ShopCanvas/ShopCanvas_3/mShopBtn3')
    public mShopBtn3: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mLeftCanvas/ShopCanvas/ShopCanvas_4/mShopBtn4')
    public mShopBtn4: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mLeftCanvas/mClothesCanvas/HairCanvas/mClothesBtn1')
    public mClothesBtn1: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mLeftCanvas/mClothesCanvas/UpperClothCanvas/mClothesBtn2')
    public mClothesBtn2: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mLeftCanvas/mClothesCanvas/LowerClothCanvas/mClothesBtn3')
    public mClothesBtn3: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mLeftCanvas/mClothesCanvas/GlovesCanvas/mClothesBtn4')
    public mClothesBtn4: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mLeftCanvas/mClothesCanvas/ShoeCanvas/mClothesBtn5')
    public mClothesBtn5: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mLeftCanvas/mClothesCanvas/BodyCanvas/mClothesBtn6')
    public mClothesBtn6: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mLeftCanvas/mClothesCanvas')
    public mClothesCanvas: UI.Canvas=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mLeftCanvas/mScrollBox/mContentCanvas')
    public mContentCanvas: UI.Canvas=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mLeftCanvas/mScrollBox')
    public mScrollBox: UI.ScrollBox=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mLeftCanvas')
    public mLeftCanvas: UI.Canvas=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mRightCanvas/RightBottomCanvas/CloseCanvas/mCloseBtn')
    public mCloseBtn: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mRightCanvas/RightBottomCanvas/SaveCanvas/mSaveBtn')
    public mSaveBtn: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mRightCanvas/RightBottomCanvas/SaveCanvas/mSaveText')
    public mSaveText: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mRightCanvas/RightBottomCanvas/SaveCanvas/mIAAImg')
    public mIAAImg: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mRightCanvas')
    public mRightCanvas: UI.Canvas=undefined;
    @UI.UIMarkPath('RootCanvas/mRecycleCanvas')
    public mRecycleCanvas: UI.Canvas=undefined;
    

	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = UI.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		//按钮添加点击
		
		this.mShopBtn1.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mShopBtn1");
		});
		this.mShopBtn1.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mShopBtn2.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mShopBtn2");
		});
		this.mShopBtn2.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mShopBtn3.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mShopBtn3");
		});
		this.mShopBtn3.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mShopBtn4.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mShopBtn4");
		});
		this.mShopBtn4.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mClothesBtn1.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mClothesBtn1");
		});
		this.mClothesBtn1.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mClothesBtn2.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mClothesBtn2");
		});
		this.mClothesBtn2.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mClothesBtn3.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mClothesBtn3");
		});
		this.mClothesBtn3.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mClothesBtn4.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mClothesBtn4");
		});
		this.mClothesBtn4.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mClothesBtn5.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mClothesBtn5");
		});
		this.mClothesBtn5.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mClothesBtn6.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mClothesBtn6");
		});
		this.mClothesBtn6.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mCloseBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mCloseBtn");
		});
		this.mCloseBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mSaveBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mSaveBtn");
		});
		this.mSaveBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		//按钮多语言
		
		//文本多语言
		
		this.initLanguage(this.mSaveText)
		
	
		//文本多语言
		
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/mLeftCanvas/ShopCanvas/ShopCanvas_1/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/mLeftCanvas/ShopCanvas/ShopCanvas_2/TextBlock_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/mLeftCanvas/ShopCanvas/ShopCanvas_3/TextBlock_2") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/mLeftCanvas/ShopCanvas/ShopCanvas_4/TextBlock_3") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/mLeftCanvas/mClothesCanvas/HairCanvas/TextBlock_4") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/mLeftCanvas/mClothesCanvas/UpperClothCanvas/TextBlock_4") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/mLeftCanvas/mClothesCanvas/LowerClothCanvas/TextBlock_4") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/mLeftCanvas/mClothesCanvas/GlovesCanvas/TextBlock_4") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/mLeftCanvas/mClothesCanvas/ShoeCanvas/TextBlock_4") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/mLeftCanvas/mClothesCanvas/BodyCanvas/TextBlock_4") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/mRightCanvas/RightBottomCanvas/CloseCanvas/CloseText") as any);
		
	
	}
	
	/*初始化多语言*/
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehavior.getBehavior("lan");
        if (call && ui) {
            call(ui);
        }
    }

	protected onShow(...params: any[]): void {};

	/*显示panel*/
    public show(...param): void {
		UI.UIManager.instance.showUI(this, this.layer, ...param);
	}

	/*隐藏panel*/
    public hide(): void {
		UI.UIManager.instance.hideUI(this);
	}
 }
 