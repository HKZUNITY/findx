﻿/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 爱玩游戏的小胖子
 * UI: UI/module/CollectionUI/CollectionPanel.ui
 * TIME: 2023.08.25-23.42.25
 */
 
@UI.UICallOnly('UI/module/CollectionUI/CollectionPanel.ui')
export default class CollectionPanel_Generate extends UI.UIBehavior {
	@UI.UIMarkPath('RootCanvas/MainCanvas/mCloseBtn')
    public mCloseBtn: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/MiddleCanvas/CollectionTypeCanvas/mCollectionBtn1')
    public mCollectionBtn1: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/MiddleCanvas/CollectionTypeCanvas/mCollectionBtn2')
    public mCollectionBtn2: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/MiddleCanvas/CollectionTypeCanvas/mCollectionBtn3')
    public mCollectionBtn3: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/MiddleCanvas/CollectionTypeCanvas/mCollectionBtn4')
    public mCollectionBtn4: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/MiddleCanvas/mScrollBox/mContentCanvas')
    public mContentCanvas: UI.Canvas=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/MiddleCanvas/mScrollBox')
    public mScrollBox: UI.ScrollBox=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mRecycleCanvas')
    public mRecycleCanvas: UI.Canvas=undefined;
    

	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = UI.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		//按钮添加点击
		
		this.mCloseBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mCloseBtn");
		});
		this.mCloseBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mCollectionBtn1.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mCollectionBtn1");
		});
		this.mCollectionBtn1.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mCollectionBtn2.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mCollectionBtn2");
		});
		this.mCollectionBtn2.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mCollectionBtn3.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mCollectionBtn3");
		});
		this.mCollectionBtn3.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mCollectionBtn4.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mCollectionBtn4");
		});
		this.mCollectionBtn4.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		//按钮多语言
		
		//文本多语言
		
		//文本多语言
		
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/MiddleCanvas/CollectionTypeCanvas/mCollectionBtn1/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/MiddleCanvas/CollectionTypeCanvas/mCollectionBtn2/TextBlock_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/MiddleCanvas/CollectionTypeCanvas/mCollectionBtn3/TextBlock_2") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/MiddleCanvas/CollectionTypeCanvas/mCollectionBtn4/TextBlock_3") as any);
		
	
	}
	
	/*初始化多语言*/
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehavior.getBehavior("lan");
        if (call && ui) {
            call(ui);
        }
    }

	protected onShow(...params: any[]): void {};

	/*显示panel*/
    public show(...param): void {
		UI.UIManager.instance.showUI(this, this.layer, ...param);
	}

	/*隐藏panel*/
    public hide(): void {
		UI.UIManager.instance.hideUI(this);
	}
 }
 