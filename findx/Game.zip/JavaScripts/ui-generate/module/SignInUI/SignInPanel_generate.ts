﻿/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 爱玩游戏的小胖子
 * UI: UI/module/SignInUI/SignInPanel.ui
 * TIME: 2023.08.25-23.42.26
 */
 
@UI.UICallOnly('UI/module/SignInUI/SignInPanel.ui')
export default class SignInPanel_Generate extends UI.UIBehavior {
	@UI.UIMarkPath('RootCanvas/MainCanvas/Canvas/Canvas_1/mSignInBtn1')
    public mSignInBtn1: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/Canvas/Canvas_1/mSignInBtn1/mSignInTxt1')
    public mSignInTxt1: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/Canvas/Canvas_1/mReawrdImage1')
    public mReawrdImage1: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/Canvas/Canvas_2/mSignInBtn2')
    public mSignInBtn2: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/Canvas/Canvas_2/mSignInBtn2/mSignInTxt2')
    public mSignInTxt2: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/Canvas/Canvas_2/mReawrdImage2')
    public mReawrdImage2: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/Canvas/Canvas_3/mSignInBtn3')
    public mSignInBtn3: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/Canvas/Canvas_3/mSignInBtn3/mSignInTxt3')
    public mSignInTxt3: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/Canvas/Canvas_3/mReawrdImage3')
    public mReawrdImage3: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/Canvas/Canvas_4/mSignInBtn4')
    public mSignInBtn4: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/Canvas/Canvas_4/mSignInBtn4/mSignInTxt4')
    public mSignInTxt4: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/Canvas/Canvas_4/mReawrdImage4')
    public mReawrdImage4: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/Canvas/Canvas_5/mSignInBtn5')
    public mSignInBtn5: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/Canvas/Canvas_5/mSignInBtn5/mSignInTxt5')
    public mSignInTxt5: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/Canvas/Canvas_5/mReawrdImage5')
    public mReawrdImage5: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/Canvas/Canvas_6/mSignInBtn6')
    public mSignInBtn6: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/Canvas/Canvas_6/mSignInBtn6/mSignInTxt6')
    public mSignInTxt6: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/Canvas/Canvas_6/mReawrdImage6')
    public mReawrdImage6: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/Canvas/Canvas_7/mSignInBtn7')
    public mSignInBtn7: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/Canvas/Canvas_7/mSignInBtn7/mSignInTxt7')
    public mSignInTxt7: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/Canvas/Canvas_7/mReawrdImage7')
    public mReawrdImage7: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mCloseButton')
    public mCloseButton: UI.Button=undefined;
    

	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = UI.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		//按钮添加点击
		
		this.mSignInBtn1.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mSignInBtn1");
		});
		this.mSignInBtn1.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mSignInBtn2.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mSignInBtn2");
		});
		this.mSignInBtn2.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mSignInBtn3.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mSignInBtn3");
		});
		this.mSignInBtn3.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mSignInBtn4.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mSignInBtn4");
		});
		this.mSignInBtn4.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mSignInBtn5.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mSignInBtn5");
		});
		this.mSignInBtn5.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mSignInBtn6.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mSignInBtn6");
		});
		this.mSignInBtn6.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mSignInBtn7.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mSignInBtn7");
		});
		this.mSignInBtn7.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mCloseButton.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mCloseButton");
		});
		this.mCloseButton.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		//按钮多语言
		
		//文本多语言
		
		this.initLanguage(this.mSignInTxt1)
		
	
		this.initLanguage(this.mSignInTxt2)
		
	
		this.initLanguage(this.mSignInTxt3)
		
	
		this.initLanguage(this.mSignInTxt4)
		
	
		this.initLanguage(this.mSignInTxt5)
		
	
		this.initLanguage(this.mSignInTxt6)
		
	
		this.initLanguage(this.mSignInTxt7)
		
	
		//文本多语言
		
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_1/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_1/TextBlock_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_1/TextBlock_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_2/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_2/TextBlock_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_2/TextBlock_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_3/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_3/TextBlock_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_3/TextBlock_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_4/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_4/TextBlock_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_4/TextBlock_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_5/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_5/TextBlock_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_5/TextBlock_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_6/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_6/TextBlock_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_6/TextBlock_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_7/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_7/TextBlock_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_7/TextBlock_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/Canvas/Canvas_7/TextBlock_1_2") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/TextBlock_3") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/TextBlock_4") as any);
		
	
	}
	
	/*初始化多语言*/
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehavior.getBehavior("lan");
        if (call && ui) {
            call(ui);
        }
    }

	protected onShow(...params: any[]): void {};

	/*显示panel*/
    public show(...param): void {
		UI.UIManager.instance.showUI(this, this.layer, ...param);
	}

	/*隐藏panel*/
    public hide(): void {
		UI.UIManager.instance.hideUI(this);
	}
 }
 