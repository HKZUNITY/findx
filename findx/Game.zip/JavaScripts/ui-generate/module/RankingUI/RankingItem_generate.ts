﻿/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 爱玩游戏的小胖子
 * UI: UI/module/RankingUI/RankingItem.ui
 * TIME: 2023.08.25-23.42.26
 */
 
@UI.UICallOnly('UI/module/RankingUI/RankingItem.ui')
export default class RankingItem_Generate extends UI.UIBehavior {
	@UI.UIMarkPath('RootCanvas/mContainerCanvas/mRankingTxt')
    public mRankingTxt: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/mContainerCanvas/mSelfNameTxt')
    public mSelfNameTxt: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/mContainerCanvas/mMaxHeightTxt')
    public mMaxHeightTxt: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/mContainerCanvas/mKillCountTxt')
    public mKillCountTxt: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/mContainerCanvas/mScoreTxt')
    public mScoreTxt: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/mContainerCanvas')
    public mContainerCanvas: UI.Canvas=undefined;
    

	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = UI.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		//按钮添加点击
		
		//按钮多语言
		
		//文本多语言
		
		this.initLanguage(this.mRankingTxt)
		
	
		this.initLanguage(this.mSelfNameTxt)
		
	
		this.initLanguage(this.mMaxHeightTxt)
		
	
		this.initLanguage(this.mKillCountTxt)
		
	
		this.initLanguage(this.mScoreTxt)
		
	
		//文本多语言
		
	}
	
	/*初始化多语言*/
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehavior.getBehavior("lan");
        if (call && ui) {
            call(ui);
        }
    }

	protected onShow(...params: any[]): void {};

	/*显示panel*/
    public show(...param): void {
		UI.UIManager.instance.showUI(this, this.layer, ...param);
	}

	/*隐藏panel*/
    public hide(): void {
		UI.UIManager.instance.hideUI(this);
	}
 }
 