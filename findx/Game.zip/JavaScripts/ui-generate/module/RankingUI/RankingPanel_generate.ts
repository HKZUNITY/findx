﻿/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 爱玩游戏的小胖子
 * UI: UI/module/RankingUI/RankingPanel.ui
 * TIME: 2023.08.25-23.42.26
 */
 
@UI.UICallOnly('UI/module/RankingUI/RankingPanel.ui')
export default class RankingPanel_Generate extends UI.UIBehavior {
	@UI.UIMarkPath('RootCanvas/MainCanvas/mTitle_txt')
    public mTitle_txt: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mFieldName/mField1_txt')
    public mField1_txt: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mFieldName/mField2_txt')
    public mField2_txt: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mFieldName/mField3_txt')
    public mField3_txt: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mFieldName/mField4_txt')
    public mField4_txt: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mFieldName/mField5_txt')
    public mField5_txt: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mFieldName')
    public mFieldName: UI.Canvas=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/ScrollView/mContent')
    public mContent: UI.Canvas=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mSelfList/mRankingTxt')
    public mRankingTxt: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mSelfList/mSelfNameTxt')
    public mSelfNameTxt: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mSelfList/mMaxHeightTxt')
    public mMaxHeightTxt: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mSelfList/mKillCountTxt')
    public mKillCountTxt: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mSelfList/mScoreTxt')
    public mScoreTxt: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mSelfList')
    public mSelfList: UI.Canvas=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/mClose_btn')
    public mClose_btn: UI.StaleButton=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/RightCanvas/RankTypeCanvas/mRankTypeText')
    public mRankTypeText: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/RightCanvas/RankMaxHeightCanvas/mMaxHeightBtn/mMaxHieghtText')
    public mMaxHieghtText: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/RightCanvas/RankMaxHeightCanvas/mMaxHeightBtn')
    public mMaxHeightBtn: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/RightCanvas/RankKillCountCanvas/mKillCountBtn/mMaxHieghtText')
    public mMaxHieghtText: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/RightCanvas/RankKillCountCanvas/mKillCountBtn')
    public mKillCountBtn: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/RightCanvas/RankScoreCanvas/mScoreBtn/mMaxHieghtText')
    public mMaxHieghtText: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/MainCanvas/RightCanvas/RankScoreCanvas/mScoreBtn')
    public mScoreBtn: UI.Button=undefined;
    

	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = UI.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		this.mClose_btn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mClose_btn");
		});
		this.initLanguage(this.mClose_btn);
		this.mClose_btn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		//按钮添加点击
		
		this.mMaxHeightBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mMaxHeightBtn");
		});
		this.mMaxHeightBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mKillCountBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mKillCountBtn");
		});
		this.mKillCountBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mScoreBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mScoreBtn");
		});
		this.mScoreBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		//按钮多语言
		
		//文本多语言
		
		this.initLanguage(this.mTitle_txt)
		
	
		this.initLanguage(this.mField1_txt)
		
	
		this.initLanguage(this.mField2_txt)
		
	
		this.initLanguage(this.mField3_txt)
		
	
		this.initLanguage(this.mField4_txt)
		
	
		this.initLanguage(this.mField5_txt)
		
	
		this.initLanguage(this.mRankingTxt)
		
	
		this.initLanguage(this.mSelfNameTxt)
		
	
		this.initLanguage(this.mMaxHeightTxt)
		
	
		this.initLanguage(this.mKillCountTxt)
		
	
		this.initLanguage(this.mScoreTxt)
		
	
		this.initLanguage(this.mRankTypeText)
		
	
		this.initLanguage(this.mMaxHieghtText)
		
	
		this.initLanguage(this.mMaxHieghtText)
		
	
		this.initLanguage(this.mMaxHieghtText)
		
	
		//文本多语言
		
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/MainCanvas/RightCanvas/RankTypeCanvas/RankTypeText") as any);
		
	
	}
	
	/*初始化多语言*/
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehavior.getBehavior("lan");
        if (call && ui) {
            call(ui);
        }
    }

	protected onShow(...params: any[]): void {};

	/*显示panel*/
    public show(...param): void {
		UI.UIManager.instance.showUI(this, this.layer, ...param);
	}

	/*隐藏panel*/
    public hide(): void {
		UI.UIManager.instance.hideUI(this);
	}
 }
 