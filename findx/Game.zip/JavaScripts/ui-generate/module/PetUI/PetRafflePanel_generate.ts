﻿/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 爱玩游戏的小胖子
 * UI: UI/module/PetUI/PetRafflePanel.ui
 * TIME: 2023.08.25-23.42.25
 */
 
@UI.UICallOnly('UI/module/PetUI/PetRafflePanel.ui')
export default class PetRafflePanel_Generate extends UI.UIBehavior {
	@UI.UIMarkPath('RootCanvas/Canvas/mCloseButton')
    public mCloseButton: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas1/mPetIcon1')
    public mPetIcon1: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas1/mSelectImage1')
    public mSelectImage1: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas2/mPetIcon2')
    public mPetIcon2: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas2/mSelectImage2')
    public mSelectImage2: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas3/mPetIcon3')
    public mPetIcon3: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas3/mSelectImage3')
    public mSelectImage3: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas4/mPetIcon4')
    public mPetIcon4: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas4/mSelectImage4')
    public mSelectImage4: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas5/mPetIcon5')
    public mPetIcon5: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas5/mSelectImage5')
    public mSelectImage5: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas6/mPetIcon6')
    public mPetIcon6: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas6/mSelectImage6')
    public mSelectImage6: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas7/mPetIcon7')
    public mPetIcon7: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas7/mSelectImage7')
    public mSelectImage7: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas8/mPetIcon8')
    public mPetIcon8: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas8/mSelectImage8')
    public mSelectImage8: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas9/mPetIcon9')
    public mPetIcon9: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas9/mSelectImage9')
    public mSelectImage9: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas10/mPetIcon10')
    public mPetIcon10: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas10/mSelectImage10')
    public mSelectImage10: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas11/mPetIcon11')
    public mPetIcon11: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas11/mSelectImage11')
    public mSelectImage11: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas12/mPetIcon12')
    public mPetIcon12: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/Canvas_1/Canvas12/mSelectImage12')
    public mSelectImage12: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/mRaffleButton/mRaffleText')
    public mRaffleText: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/mRaffleButton')
    public mRaffleButton: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/Canvas/mPetButton')
    public mPetButton: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/mGetCanvas/mCloseGetButton')
    public mCloseGetButton: UI.Button=undefined;
    @UI.UIMarkPath('RootCanvas/mGetCanvas/Canvas_3/mGetImage')
    public mGetImage: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/mGetCanvas')
    public mGetCanvas: UI.Canvas=undefined;
    

	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = UI.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		//按钮添加点击
		
		this.mCloseButton.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mCloseButton");
		});
		this.mCloseButton.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mRaffleButton.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mRaffleButton");
		});
		this.mRaffleButton.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mPetButton.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mPetButton");
		});
		this.mPetButton.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mCloseGetButton.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mCloseGetButton");
		});
		this.mCloseGetButton.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		//按钮多语言
		
		//文本多语言
		
		this.initLanguage(this.mRaffleText)
		
	
		//文本多语言
		
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas/mPetButton/RaffleText") as any);
		
	
	}
	
	/*初始化多语言*/
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehavior.getBehavior("lan");
        if (call && ui) {
            call(ui);
        }
    }

	protected onShow(...params: any[]): void {};

	/*显示panel*/
    public show(...param): void {
		UI.UIManager.instance.showUI(this, this.layer, ...param);
	}

	/*隐藏panel*/
    public hide(): void {
		UI.UIManager.instance.hideUI(this);
	}
 }
 