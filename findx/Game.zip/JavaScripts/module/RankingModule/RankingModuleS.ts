﻿import Console from "../../Tools/Console";
import HUDModuleS from "../HUDModule/HUDModuleS";
import ShopData from "../ShopModule/ShopData";
import RankingModuleC from "./RankingModuleC";

export default class RankingModuleS extends ModuleS<RankingModuleC, null> {
    /**储存所有玩家的数据 */
    private playerDataMap: Map<number, PlayerData> = new Map<number, PlayerData>();
    private hudModuleS: HUDModuleS = null;
    private get getHUDModuleS(): HUDModuleS {
        if (this.hudModuleS == null) {
            this.hudModuleS = ModuleManager.getInstance().getModule(HUDModuleS);
        }
        return this.hudModuleS;
    }
    /** 当脚本被实例后，会在第一帧更新前调用此函数 */
    protected onStart(): void {
        Console.error("[RankingModuleC-onStart]");
        this.registerEvents();
    }

    /**注册事件 */
    private registerEvents(): void {
        Events.addClientListener("RefreshMaxHeight", this.refreshMaxHeight.bind(this));
    }

    public net_A(v: number): void {
        if (!this.playerDataMap.has(this.currentPlayerId)) return;
        let playerData = this.playerDataMap.get(this.currentPlayerId);
        playerData.maxHeight += v;
        this.sendPlayersData();
    }

    public net_B(v: number): void {
        if (!this.playerDataMap.has(this.currentPlayerId)) return;
        let playerData = this.playerDataMap.get(this.currentPlayerId);
        playerData.killCount += v;
        this.sendPlayersData();
    }

    public net_C(v: number): void {
        if (!this.playerDataMap.has(this.currentPlayerId)) return;
        let playerData = this.playerDataMap.get(this.currentPlayerId);
        playerData.score += v;
        this.getHUDModuleS.setPlayerLevel(this.currentPlayerId, playerData.score);
        this.sendPlayersData();
    }

    /**刷新历史最高 */
    private refreshMaxHeight(player: Gameplay.Player, recordMaxHight: number): void {
        let playerId = player.getPlayerID();
        if (!this.playerDataMap.has(playerId)) return;
        let playerData = this.playerDataMap.get(playerId);
        playerData.maxHeight = recordMaxHight;
        DataCenterS.getInstance().getData(player, ShopData).saveMaxHeight(recordMaxHight);
        this.sendPlayersData();
    }

    /**刷新击杀人数 */
    public refreshKillCount(player: Gameplay.Player, killCount: number): void {
        let playerId = player.getPlayerID();
        Console.error("[击杀playerId] = " + playerId);
        if (!this.playerDataMap.has(playerId)) return;
        let playerData = this.playerDataMap.get(playerId);
        playerData.killCount += killCount;
        DataCenterS.getInstance().getData(player, ShopData).saveKillCount(playerData.killCount);
        this.sendPlayersData();
    }

    /**刷新收集分数 */
    public refreshScore(player: Gameplay.Player, score: number): void {
        let playerId = player.getPlayerID();
        Console.error("[冲击的PlayerId] = " + playerId);
        if (!this.playerDataMap.has(playerId)) return;
        let playerData = this.playerDataMap.get(playerId);
        playerData.score += score;
        DataCenterS.getInstance().getData(player, ShopData).saveLevel(playerData.score);
        this.getHUDModuleS.setPlayerLevel(playerId, playerData.score);
        this.sendPlayersData();
    }

    /**生命周期方法-进入场景调用(客户端发来的) */
    public net_onEnterScene(playerId: number, playerName: string, score: number, killCount: number, maxHeight: number): void {
        let playerData = new PlayerData();
        playerData.playerName = playerName;
        playerData.score = score;
        playerData.killCount = killCount;
        playerData.maxHeight = maxHeight;
        this.playerDataMap.set(playerId, playerData);
        this.sendPlayersData();
        this.getHUDModuleS.setPlayerLifeNickName(playerId, playerName, playerData.score);
    }

    /**生命周期方法-玩家离开房间 */
    protected onPlayerLeft(player: Gameplay.Player): void {
        Console.error("[playerId：" + player.getPlayerID() + "的玩家离开房间]");
        let playerId = player.getPlayerID();
        if (!this.playerDataMap.has(playerId)) return;
        this.playerDataMap.delete(playerId);
        this.sendPlayersData();
    }

    /**发送给所有客户端所有玩家的数据 */
    private sendPlayersData(): void {
        let playerIds: number[] = [];
        let playerNames: string[] = [];
        let maxHeights: number[] = [];
        let killCounts: number[] = [];
        let scores: number[] = [];
        this.playerDataMap.forEach((playerData: PlayerData, playerId: number) => {
            playerIds.push(playerId);
            playerNames.push(playerData.playerName);
            maxHeights.push(playerData.maxHeight);
            killCounts.push(playerData.killCount);
            scores.push(playerData.score);
        });
        this.getAllClient().net_receivePlayersData(playerIds, playerNames, maxHeights, killCounts, scores);
    }
}

/**数据（玩家） */
export class PlayerData {
    public playerId: number = null;
    public playerName: string = "";
    public maxHeight: number = 0;
    public killCount: number = 0;
    public score: number = 0;
}