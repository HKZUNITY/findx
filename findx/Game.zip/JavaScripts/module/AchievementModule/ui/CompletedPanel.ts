﻿import { GameConfig } from "../../../config/GameConfig";
import Completed_Generate from "../../../ui-generate/module/Achievement/Completed_generate";

export default class CompletedPanel extends Completed_Generate {

	/** 
	 * 构造UI文件成功后，在合适的时机最先初始化一次 
	 */
	protected onStart() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = UI.UILayerMiddle;
		this.initDatas();
	}
	private topVector2: Type.Vector2 = new Type.Vector2(0, 0);
	private downVector2: Type.Vector2 = new Type.Vector2(0, 0);
	private topToDownTween: Util.TweenUtil.Tween<any> = null;
	private downToTopTween: Util.TweenUtil.Tween<any> = null;
	/**初始化数据 */
	private initDatas(): void {
		let positionX = this.rootCanvas.size.x / 2 - this.mCanvas.size.x / 2;
		this.topVector2 = new Type.Vector2(positionX, -this.mCanvas.size.y);
		this.downVector2 = new Type.Vector2(positionX, 0);
	}

	protected onShow(...params: any[]): void {
		if (this.topToDownTween != null) this.topToDownTween.stop();
		if (this.downToTopTween != null) this.downToTopTween.stop();
		this.mCanvas.position = this.topVector2;
		this.topToDownTween = new Util.TweenUtil.Tween({ x: this.topVector2.x, y: this.topVector2.y })
			.to({ x: this.downVector2.x, y: this.downVector2.y }, 0.3 * 1000)
			.onUpdate((v) => {
				this.mCanvas.position = new Type.Vector2(v.x, v.y);
			})
			.onComplete(() => {
				TimeUtil.delaySecond(2).then(() => {
					this.downToTopTween = new Util.TweenUtil.Tween({ x: this.downVector2.x, y: this.downVector2.y }).
						to({ x: this.topVector2.x, y: this.topVector2.y }, 0.3 * 1000)
						.onUpdate((v) => {
							this.mCanvas.position = new Type.Vector2(v.x, v.y);
						})
						.onComplete(() => {
							this.hide();
						})
						.start();
				});
			})
			.start();
	}

	/**
	 * 达到条件提示25% 50% 75% 100%
	 * @param achId 成就
	 * @param isOnComplete 是否完成 
	 * @param progress 进度
	 * @param tragetNum 目标数
	 * @param currentValue 当前值
	 */
	public showCompletedTips(achId: number, isOnComplete: boolean, progress: number = 0, tragetNum: number = 0, currentValue: number): void {
		let achievementsElement = GameConfig.Achievements.getElement(achId);
		this.mText_AMname.text = achievementsElement.Name;
		if (isOnComplete) {
			this.mProgressBar.visibility = UI.SlateVisibility.Collapsed;
			this.mText_Target.visibility = UI.SlateVisibility.Collapsed;
			this.mText_Finish.visibility = UI.SlateVisibility.SelfHitTestInvisible;
		}
		else {
			this.mProgressBar.visibility = UI.SlateVisibility.SelfHitTestInvisible;
			this.mText_Target.visibility = UI.SlateVisibility.SelfHitTestInvisible;
			this.mText_Finish.visibility = UI.SlateVisibility.Collapsed;
			this.mProgressBar.currentValue = currentValue;
			this.mText_Target.text = progress + "/" + tragetNum;
		}
		this.show();
	}
}
