﻿import Console from "../../Tools/Console";
import { Utils } from "../../Tools/utils";
import HUDModuleC from "../HUDModule/HUDModuleC";
import SignInModuleC from "../SignInModule/SignInModuleC";
import PetPanel from "./ui/PetPanel";
import PetRafflePanel from "./ui/PetRafflePanel";

export class PetData extends Subdata {
    /**宠物集合 */
    @Decorator.saveProperty
    public petList: number[] = [];
    /**上次登录时间 */
    @Decorator.saveProperty
    public lastPetDay: string = "";
    /**是否拥有免费次数 */
    @Decorator.saveProperty
    public isFreeCount: boolean = true;
    /**抽奖宠物集合 */
    @Decorator.saveProperty
    public petRaffleList: number[] = [];

    protected initDefaultData(): void {
        this.petList = [];
        this.petRaffleList = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
        this.lastPetDay = "";
        this.isFreeCount = true;
    }

    /**保存宠物 */
    public savePetList(value: number): void {
        this.petList.push(value);
        this.save(true);
    }

    public saveIsFreeCount(value: boolean): void {
        this.isFreeCount = value;
        this.save(true);
    }

    /**
     * 记录今天是那一天
     * @param whatDay 那一天
     */
    public saveLastPetDayAndRandomIds(whatDay: string, value: number[]): void {
        this.lastPetDay = whatDay;
        this.petRaffleList = value;
        this.save(true);
    }
}

export class PetModuleC extends ModuleC<PetModuleS, PetData> {
    private hudModuleC: HUDModuleC = null;
    private petPanel: PetPanel = null;
    private petRafflePanel: PetRafflePanel = null;

    protected onStart(): void {
        this.initData();
        this.registerAction();
    }

    private initData(): void {
        this.hudModuleC = ModuleManager.getInstance().getModule(HUDModuleC);
        this.petPanel = UI.UIManager.instance.getUI(PetPanel);
        this.petRafflePanel = UI.UIManager.instance.getUI(PetRafflePanel);
    }

    private registerAction(): void {
        this.hudModuleC.onOpenPetAction.add(() => {
            this.petPanel.show();
        });
        this.hudModuleC.onOpenRaffleAction.add(() => {
            this.petRafflePanel.show();
        });

        InputUtil.onKeyDown(Type.Keys.H, () => {
            this.savePetList(Utils.getRandomInteger(1, 18));
        });
    }

    private followASpeed: number = 0.01;
    // private followBSpeed: number = 0.02;
    private pet: Gameplay.NPC = null;
    private appearance: Gameplay.HumanoidV1 = null;
    private prePlayerLoc: Type.Vector = null;
    private petGuid: string = null;
    private petTween: Util.TweenUtil.Tween<any> = null;

    protected onEnterScene(sceneType: number): void {
        this.initPetData();
        TimeUtil.setInterval(() => {
            this.petMoveToPlayer();
        }, this.followASpeed);

        TimeUtil.delaySecond(3).then(() => {
            let curWhatDay = Utils.getDay();
            let ids: number[] = [];
            if (this.data.lastPetDay != curWhatDay) {
                ids = Utils.getRandomArr([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18], 12);
                this.saveLastPetDayAndRandomIds(curWhatDay, ids);
                this.saveIsFreeCount(true);
            }
            else {
                ids = this.data.petRaffleList;
            }
            this.petRafflePanel.updateIcons(ids);
        });
    }

    private async initPetData(): Promise<void> {
        this.pet = await Core.GameObject.asyncFind("33B99E35") as Gameplay.NPC;
        this.pet.setWorldScale(Type.Vector.one.multiply(0.5));
        this.pet.playAnimation("46298", 0);
        this.pet.collisionWithOtherCharacterEnable = false;
        this.pet.characterName = "";
        this.prePlayerLoc = this.pet.getWorldLocation();

        this.pet.appearanceType = Gameplay.AppearanceType.HumanoidV1;
        this.appearance = this.pet.getAppearance<Gameplay.HumanoidV1>();
    }

    public changePet(petGuid: string): void {
        this.petGuid = null;
        this.currentPlayer.character.addMoveInput(this.currentPlayer.character.getForwardVector());
        this.setWholeBody(petGuid);
    }

    private setWholeBody(petGuid: string): void {
        this.appearance.setWholeBody(petGuid, false);
        this.petGuid = petGuid;
    }

    private petMoveToPlayer(): void {
        if (this.petGuid != null) {
            // Console.log("[hkz]");

            let playerLoc = this.currentPlayer.character.getWorldLocation();
            if (Math.abs(playerLoc.x - this.prePlayerLoc.x) < 0.1
                && Math.abs(playerLoc.y - this.prePlayerLoc.y) < 0.1
                && Math.abs(playerLoc.z - this.prePlayerLoc.z) < 0.1) return;

            this.prePlayerLoc = playerLoc;

            let playerForward = this.currentPlayer.character.getForwardVector();
            let offsetLocRight = this.currentPlayer.character.getRightVector();

            let offsetLoc = new Type.Vector((playerForward.x * -50) + (offsetLocRight.x * 50), (playerForward.y * -50) + (offsetLocRight.y * 50), 50);
            let toLoc = new Type.Vector(playerLoc.x + offsetLoc.x, playerLoc.y + offsetLoc.y, playerLoc.z + offsetLoc.z);

            // let fromLoc = this.pet.getWorldLocation();
            this.pet.setWorldRotation(new Type.Rotation(playerForward, Type.Vector.zero));
            this.pet.setWorldLocation(toLoc);
            // if (this.petTween) {
            //     this.petTween.stop();
            //     this.petTween = null;
            // }
            // this.petTween = new Util.TweenUtil.Tween({ x: fromLoc.x, y: fromLoc.y, z: fromLoc.z })
            //     .to({ x: toLoc.x, y: toLoc.y, z: toLoc.z }, this.followBSpeed * 1000)
            //     .onUpdate((obj) => {
            //         this.pet.setWorldLocation(new Type.Vector(obj.x, obj.y, obj.z));
            //     }).start();
        }
    }

    public savePetList(pet: number): void {
        if (this.data.petList.includes(pet)) return;
        this.petPanel.getPetItem(pet);
        this.server.net_savePetList(pet);
    }

    public saveLastPetDayAndRandomIds(petLastDay: string, value: number[]): void {
        this.server.net_saveLastPetDayAndRandomIds(petLastDay, value);
    }

    public saveIsFreeCount(value: boolean): void {
        this.server.net_saveIsFreeCount(value);
    }

    public getIsFreeCount(): boolean {
        return this.data.isFreeCount;
    }

    public isOwn(id: number): boolean {
        return this.data.petList.includes(id);
    }
}

export class PetModuleS extends ModuleS<PetModuleC, PetData> {

    protected onStart(): void {
    }

    protected onPlayerEnterGame(player: Gameplay.Player): void {

    }
    protected onPlayerLeft(player: Gameplay.Player): void {

    }

    public net_savePetList(pet: number): void {
        this.currentData.savePetList(pet);
    }

    public net_saveLastPetDayAndRandomIds(petLastDay: string, value: number[]): void {
        this.currentData.saveLastPetDayAndRandomIds(petLastDay, value);
    }

    public net_saveIsFreeCount(value: boolean): void {
        this.currentData.saveIsFreeCount(value);
    }
}