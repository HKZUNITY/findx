﻿import BaseAI from "../../Prefabs/AI敌人/Script/BaseAI";
import { PrefabEvent } from "../../Prefabs/PrefabEvent";
import Console from "../../Tools/Console";
import { Utils } from "../../Tools/utils";
import GlobalData from "../../const/GlobalData";
import NPCBar from "../NPCModule/NPCBar";
import RankingModuleS from "../RankingModule/RankingModuleS";
import HUDDate from "./HUDDate";
import HUDModuleC from "./HUDModuleC";
import Lifebar from "./ui/Lifebar";

export default class HUDModuleS extends ModuleS<HUDModuleC, HUDDate> {
    private rankingModuleS: RankingModuleS = null;
    private get getRankingModuleS(): RankingModuleS {
        if (this.rankingModuleS == null) {
            this.rankingModuleS = ModuleManager.getInstance().getModule(RankingModuleS);
        }
        return this.rankingModuleS;
    }

    /** 当脚本被实例后，会在第一帧更新前调用此函数 */
    protected onStart(): void {
        this.initAIData();
        this.registerAIEvents();
    }

    /**初始化AI数据 */
    private initAIData(): void {
        this.npcGuids = this.npcString.split(',');
        let i = 0;
        let len = GlobalData.aiGuids.length;
        let id = TimeUtil.setInterval(async () => {
            let npc = await Core.GameObject.asyncFind(GlobalData.aiGuids[i]) as Gameplay.NPC;
            npc.characterName = "";
            let npcAI = npc.getScriptByGuid(GlobalData.aiNPCs[i]) as BaseAI;
            let aIData = new AIData();
            let npcBar = await Gameplay.Script.spawnScript(NPCBar, true, npc);
            npcBar.hp = GlobalData.aiHps[i];
            npcBar.maxHp = GlobalData.aiHps[i];
            aIData.npc = npc;
            aIData.npcAI = npcAI;
            aIData.npcBar = npcBar;
            let app = aIData.npc.setAppearance(Gameplay.HumanoidV2);
            app.setAppearanceData([this.getOneNPC()], () => {
                app.appearanceSync();
            });
            aIData.npc.setWorldScale(Type.Vector.one.multiply(this.randomNum()));
            // Console.error("[hkz - aIData.hp] = " + aIData.hp);
            this.aiMap.set(GlobalData.aiGuids[i], aIData);
            ++i;
            if (i >= len) {
                TimeUtil.clearInterval(id);
            }
        }, 1);
    }

    private playerAIMap: Map<string, Gameplay.Player> = new Map<string, Gameplay.Player>();
    private aiMap: Map<string, AIData> = new Map<string, AIData>();
    private npcGuids: string[] = [];;
    private npcString: string = "8249B6BE440D874D64EC80AA47CAE6CF,162971,163330,136183,142879,141623,136298,137837,141926,141927,141928,142184,142188,142191,142192,142258,142260,142922,142926,142923,142928,142927,142136,142137,142138,142261,142257,142925,143236,143227,142914,142913,143234,141618,142193,142194,142915,142916,142917,142918,142919,142920,142924,142929,142930,143226,143228,143229,143230,143231,143233,142907,142888,142900,142889,142884,142885,142886,142887,142890,142891,142892,142893,142894,142895,142896,142898,142901,142272,142903,142904,142905,142906,142899";
    /**注册AI事件 */
    private registerAIEvents(): void {
        PrefabEvent.PrefabEvtFight.onHurt(async (senderGuid: string, targetGuid: string, damage: number) => {
            if (this.playerAIMap.has(targetGuid)) {
                let pl = this.playerAIMap.get(targetGuid);
                this.setPlayerHp(pl, damage);
                EffectService.getInstance().playEffectOnGameObject("107541", pl.character, 1, Type.Vector.zero, Type.Rotation.zero, Type.Vector.one.multiply(5));
                SoundService.getInstance().play3DSound("47414", pl.character, 1, 10000);
            }
            else {
                if (!this.aiMap.has(targetGuid)) return;
                if (this.aiMap.get(targetGuid).isDie) return;
                let aIData = this.aiMap.get(targetGuid);
                let curHp = aIData.npcBar.hp;
                curHp -= damage;
                if (curHp <= 0) {
                    if (this.playerAIMap.has(senderGuid)) this.getRankingModuleS.refreshKillCount(this.playerAIMap.get(senderGuid), 1);
                    let loc = aIData.npc.getWorldLocation();
                    this.spawnTombstoneAIS(loc);
                    aIData.isDie = true;
                    aIData.npcBar.hp = 0;
                    let hp = 0;
                    if (aIData.npcBar.maxHp < 9999999) {
                        hp = aIData.npcBar.maxHp * this.randomNum();
                    } else {
                        hp = aIData.npcBar.maxHp;
                    }
                    aIData.npcAI.hp = hp;
                    if (aIData.npcAI.aggressivity < 1000) {
                        aIData.npcAI.aggressivity = Math.round(aIData.npcAI.aggressivity * this.randomNum());
                    }
                    TimeUtil.delaySecond(5).then(() => {
                        aIData.npcBar.hp = hp;
                        aIData.npcBar.maxHp = hp;
                        aIData.isDie = false;
                        let app = aIData.npc.setAppearance(Gameplay.HumanoidV2);
                        app.setAppearanceData([this.getOneNPC()], () => {
                            app.appearanceSync();
                        });
                        aIData.npc.setWorldScale(Type.Vector.one.multiply(this.randomNum()));
                        aIData.npc.setWorldLocation(new Type.Vector(loc.x, loc.y, loc.z + 500));
                        if (aIData.npc.ragdollEnable) {
                            aIData.npc.ragdollEnable = false;
                        }
                    });
                } else {
                    aIData.npcBar.hp = curHp;
                }
                // Console.error("[hkz - aIData.hp] = " + aIData.hp);
                this.aiMap.set(targetGuid, aIData);
                EffectService.getInstance().playEffectOnGameObject("107541", aIData.npc, 1, Type.Vector.zero, Type.Rotation.zero, Type.Vector.one.multiply(5));
                SoundService.getInstance().play3DSound("47414", aIData.npc, 1, 10000);
            }
        });
    }

    private getOneNPC(): string {
        return this.npcGuids[Utils.getRandomInteger(0, this.npcGuids.length - 1)];
    }

    /**随机1到2的数保留一位小数 */
    private randomNum(): number {
        let num = Math.random().toFixed(1);
        return Number(num) + 1;
    }

    /**生成墓碑（服务端） */
    private spawnTombstoneAIS(pos1: Type.Vector): void {
        let tombstone: Gameplay.GameObject = null;
        tombstone = Gameplay.GameObject.spawnGameObject("110950");
        tombstone.setWorldLocation(new Type.Vector(pos1.x, pos1.y, pos1.z - 110));
        setTimeout(() => {
            tombstone.destroy();
        }, 5 * 1000);
    }

    /**生命周期方法-玩家进入游戏(客户端已就绪，数据就绪，前后端可正常通信) */
    protected onPlayerEnterGame(player: Gameplay.Player): void {
        this.playerAIMap.set(player.character.guid, player);
        this.setPlayerLifeData(player);
        /**-----[玩家进入游戏同步其他玩家的翅膀]----- */
        let wingPlayerIds: number[] = [];
        let wingIds: number[] = [];
        if (this.wingMap.size > 0) {
            this.wingMap.forEach((wingId: number, wingPlayerId: number) => {
                wingPlayerIds.push(wingPlayerId);
                wingIds.push(wingId);
            });
        }
        /**-----[玩家进入游戏同步其他玩家的翅膀]----- */

        /**-----[玩家进入游戏同步其他玩家的拖尾特效]----- */
        let tailEffectplayerIds: number[] = [];
        let tailEffectIds: number[] = [];
        if (this.wingTailEffect.size > 0) {
            this.wingTailEffect.forEach((tailEffectId: number, tailEffectplayerId: number) => {
                tailEffectplayerIds.push(tailEffectplayerId);
                tailEffectIds.push(tailEffectId);
            });
        }
        /**-----[玩家进入游戏同步其他玩家的拖尾特效]----- */

        /**-----[玩家进入游戏同步其他玩家的武器]----- */
        let weaponPlayerIds: number[] = [];
        let weaponIds: number[] = [];
        if (this.weaponIdMap.size > 0) {
            this.weaponIdMap.forEach((weaponId: number, weaponPlayerId: number) => {
                weaponPlayerIds.push(weaponPlayerId);
                weaponIds.push(weaponId);
            });
        }
        /**-----[玩家进入游戏同步其他玩家的武器]----- */
        if (wingPlayerIds.length == 0
            && tailEffectplayerIds.length == 0
            && weaponPlayerIds.length == 0) return;
        this.getClient(player).net_enterGameSnycData(
            wingPlayerIds, wingIds,
            tailEffectplayerIds, tailEffectIds,
            weaponPlayerIds, weaponIds
        );
    }

    /**生命周期方法-玩家离开房间 */
    protected onPlayerLeft(player: Gameplay.Player): void {
        let playerId = player.getPlayerID();
        this.deletePlayerLifeData(playerId);
        this.deleteWingMap(playerId);
        this.deleteTailEffectMap(playerId);
        this.deleteWeaponMap(playerId);
        if (this.playerAIMap.has(player.character.guid)) {
            this.playerAIMap.delete(player.character.guid);
        }
        this.getAllClient().net_exitGameSyncData(playerId);
    }

    //#region 翅膀
    /**---------------------------------【翅膀】--------------------------------- */
    /**储存房间内所有玩家的翅膀 */
    private wingMap: Map<number, number> = new Map<number, number>();

    /**拾取翅膀发给所有客户端 */
    public net_pickWing(id: number): void {
        this.wingMap.set(this.currentPlayerId, id);
        this.getAllClient().net_pickUpWing(this.currentPlayerId, id);
    }

    /**玩家离开房间删除翅膀数据 */
    private deleteWingMap(playerId: number): void {
        if (!this.wingMap.has(playerId)) return;
        this.wingMap.delete(playerId);
    }
    /**---------------------------------【翅膀】--------------------------------- */
    //#endregion

    //#region 拖尾特效
    /**------------------------------【拖尾特效】------------------------------*/
    /**储存房间内所有玩家的拖尾特效 */
    private wingTailEffect: Map<number, number> = new Map<number, number>();

    /**拾取拖尾特效发给所有客户端 */
    public net_pickTailEffect(id: number): void {
        this.wingTailEffect.set(this.currentPlayerId, id);
        this.getAllClient().net_pickUpTailEffect(this.currentPlayerId, id);
    }

    /**玩家离开房间删除特效数据 */
    private deleteTailEffectMap(playerId: number): void {
        if (!this.wingTailEffect.has(playerId)) return;
        this.wingTailEffect.delete(playerId);
    }
    /**------------------------------【拖尾特效】------------------------------*/
    //#endregion

    //#region 武器-攻击
    /**------------------------------【武器-攻击】------------------------------*/
    /**存储所有玩家的生命数据 */
    private playerLifeMap: Map<number, PlayerData> = new Map<number, PlayerData>();
    /**设置player的头顶UI姓名 */
    public setPlayerLifeNickName(playerId: number, nickName: string, level: number): void {
        if (!this.playerLifeMap.has(playerId)) return;
        let lifebar = this.playerLifeMap.get(playerId).lifebar;
        lifebar.playerName = nickName;
        lifebar.playerLevel = level;
    }

    /**设置玩家等级 */
    public setPlayerLevel(playerId: number, level: number): void {
        if (!this.playerLifeMap.has(playerId)) return;
        this.playerLifeMap.get(playerId).lifebar.playerLevel = level;
    }

    /**升级 */
    public net_addLevel(): void {
        this.getRankingModuleS.refreshScore(this.currentPlayer, 1);
    }

    public net_addLevel1(): void {
        this.getRankingModuleS.refreshScore(this.currentPlayer, 20);
    }

    public net_addLevel2(): void {
        this.getRankingModuleS.refreshScore(this.currentPlayer, 30);
    }

    public net_addLevel3(lv: number): void {
        this.getRankingModuleS.refreshScore(this.currentPlayer, lv);
    }

    /**设置玩家血量 */
    private setPlayerHp(player: Gameplay.Player, hp: number, addPlayer: Gameplay.Player = null): void {
        let playerId = player.getPlayerID();
        let playerAttackData = this.playerLifeMap.get(playerId);
        if (playerAttackData.isDie) return;
        if (playerAttackData.isWudi) return;
        this.getClient(player).net_FlyText(hp);
        let curHp = playerAttackData.lifebar.hp;
        curHp -= hp;
        if (curHp <= 0) {
            playerAttackData.lifebar.hp = 0;
            playerAttackData.isDie = true;
            if (addPlayer) {
                this.getRankingModuleS.refreshKillCount(addPlayer, 1);
                this.getClient(addPlayer).net_killAch();
            }
            player.character.ragdollEnable = true;
            this.spawnTombstoneS(player);
            TimeUtil.delaySecond(3).then(() => {
                player.character.ragdollEnable = false;
                playerAttackData.lifebar.hp = DataCenterS.getInstance().getData(player, HUDDate).maxHp;
                playerAttackData.isDie = false;
                this.getClient(player).net_rebirthHome();
                playerAttackData.isWudi = true;
                let effectId = EffectService.getInstance().playEffectOnPlayer("140173", player, Gameplay.SlotType.Root, 0, Type.Vector.zero, Type.Rotation.zero, Type.Vector.one.multiply(2));
                TimeUtil.delaySecond(5).then(() => {
                    playerAttackData.isWudi = false;
                    EffectService.getInstance().stopEffect(effectId);
                })
            });
        }
        else {
            playerAttackData.lifebar.hp = curHp;
        }
        Console.error("[hp] = " + this.playerLifeMap.get(playerId).lifebar.hp);
    }

    /**生成墓碑（服务端） */
    private spawnTombstoneS(player: Gameplay.Player): void {
        let tombstone: Gameplay.GameObject = null;
        tombstone = Gameplay.GameObject.spawnGameObject("110950");
        let pos = player.character.getWorldLocation();
        tombstone.setWorldLocation(new Type.Vector(pos.x, pos.y, pos.z - 110));
        setTimeout(() => {
            tombstone.destroy();
        }, 3 * 1000);
    }

    /**设置玩家生命数据 */
    private async setPlayerLifeData(player: Gameplay.Player): Promise<void> {
        let playerId = player.getPlayerID();
        let playerAttackData = new PlayerData();
        let hpbar = await Gameplay.Script.spawnScript(Lifebar, true, player.character);
        let maxHp = DataCenterS.getInstance().getData(player, HUDDate).maxHp;
        hpbar.maxHp = maxHp;
        hpbar.hp = maxHp;
        playerAttackData.lifebar = hpbar;
        playerAttackData.isDie = false;
        this.playerLifeMap.set(playerId, playerAttackData);
    }

    /**删除玩家生命数据 */
    private deletePlayerLifeData(playerId: number): void {
        if (!this.playerLifeMap.has(playerId)) return;
        this.playerLifeMap.get(playerId).lifebar.destroy();
        this.playerLifeMap.delete(playerId);
    }

    /**
     * 攻击玩家
     * @param playerIds 被攻击到的玩家ID 
     */
    public net_attackPlayer(playerIds: number[], aiIds: string[], ImpulseValue: number, badValue: number, weaponId: number): void {
        if (aiIds.length != 0) {
            for (let i = 0; i < aiIds.length; ++i) {
                PrefabEvent.PrefabEvtFight.hurt(this.currentPlayer.character.guid, aiIds[i], badValue);
            }
        }
        if (playerIds.length == 0) return;
        if (this.playerLifeMap.get(this.currentPlayerId).isDie) return;
        let forwardVector = this.currentPlayer.character.getForwardVector();
        let forwardMultiply = forwardVector.multiply(ImpulseValue);

        for (const playerId of playerIds) {
            let player = Gameplay.getPlayer(playerId);
            player.character.addImpulse(forwardMultiply, true);
            this.setPlayerHp(player, badValue, this.currentPlayer);
        }
        this.getAllClient().net_playHitEffect(playerIds, weaponId);
    }

    /**播放攻击动画、特效、音效（服务端同步给所有客户端执行某个客户端的攻击表现） */
    public net_playAniEffSound(weaponId: number): void {
        if (this.playerLifeMap.get(this.currentPlayerId).isDie) return;
        this.getAllClient().net_playAniEffSound(this.currentPlayerId, weaponId);
    }

    /**服务端存储房间内所有玩家所持有的武器数据 */
    private weaponIdMap: Map<number, number> = new Map<number, number>();

    /**拾取武器（广播给所有客户端） */
    public net_pickUpWeapon(id: number): void {
        this.weaponIdMap.set(this.currentPlayerId, id);
        this.getAllClient().net_pickUpWeapon(this.currentPlayerId, id);
    }

    /**玩家离开游戏删除所持有武器数据 */
    private deleteWeaponMap(playerId: number): void {
        if (!this.weaponIdMap.has(playerId)) return;
        this.weaponIdMap.delete(playerId);
    }
    /**------------------------------【武器-攻击】------------------------------*/
    //#endregion

    //#region 玩家属性
    /**设置最大血量 */
    public net_setMaxHp(maxHp: number): void {
        let playerAttackData = this.playerLifeMap.get(this.currentPlayerId);
        playerAttackData.lifebar.maxHp = maxHp;
        this.currentData.saveMaxHp(maxHp);
    }

    /**设置当前血量 */
    public net_setCurHp(curAddHp: number): void {
        let playerAttackData = this.playerLifeMap.get(this.currentPlayerId);
        let maxHp = playerAttackData.lifebar.maxHp;
        let curHp = playerAttackData.lifebar.hp;
        curHp += curAddHp;
        if (curHp >= maxHp) {
            curHp = maxHp;
        }
        playerAttackData.lifebar.hp = curHp;
    }

    /**设置当前攻击力 */
    public net_setCurAttackValue(curAttackValue: number): void {
        this.currentData.saveHurt(curAttackValue);
    }
    //#endregion
}

class PlayerData {
    public lifebar: Lifebar = null;
    public isDie: boolean = false;
    public isWudi: boolean = false
}

class AIData {
    public npcBar: NPCBar = null
    public npc: Gameplay.NPC = null;
    public npcAI: BaseAI = null;
    public isDie: boolean = false;
}