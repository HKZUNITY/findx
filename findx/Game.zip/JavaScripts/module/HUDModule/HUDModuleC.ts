﻿import Console from "../../Tools/Console";
import { Utils } from "../../Tools/utils";
import AdTips from "../../common/AdTips";
import { ExplosiveCoins } from "../../common/ExplosiveCoins";
import { FlyText } from "../../common/FlyText";
import Tips from "../../common/P_Tips";
import Test from "../../common/Test";
import { GameConfig } from "../../config/GameConfig";
import { IMusicElement } from "../../config/Music";
import { IWeaponElement } from "../../config/Weapon";
import GlobalData from "../../const/GlobalData";
import AchievementModuleC from "../AchievementModule/AchievementModuleC";
import { AdType } from "../AdsModule/AdsModuleC";
import PetPanel from "../PetModule/ui/PetPanel";
import ShopModuleC from "../ShopModule/ShopModuleC";
import HUDDate from "./HUDDate";
import HUDModuleS from "./HUDModuleS";
import GuidePanel from "./ui/GuidePanel";
import HUDPanel from "./ui/HUDPanel";

export default class HUDModuleC extends ModuleC<HUDModuleS, HUDDate> {
    private hudPanel: HUDPanel = null;
    /**皮肤商店模块 */
    private shopModuleC: ShopModuleC = null;
    private achievementModuleC: AchievementModuleC = null;
    private guidePanel: GuidePanel = null;
    private adTips: AdTips = null;
    private petPanel: PetPanel = null;
    /**跳跃事件 */
    public onJumpAction: Action = new Action();
    /**背景音乐事件 */
    public onMusicAction: Action = new Action();
    /**打开排行榜的事件 */
    public onOpenRankingAction: Action = new Action();
    /**打开皮肤商店 */
    public onSkinShopAction: Action = new Action();
    /**打开关闭收集Panel */
    public onOpenAndCloseCollectionPanelAction: Action1<boolean> = new Action1<boolean>();
    /**打开签到界面 */
    public onOpenSignInAction: Action = new Action();
    public onOpenSignInAction1: Action = new Action();
    /**打开抽奖界面 */
    public onOpenAdsAction: Action = new Action();
    /**打开成就界面 */
    public onOpenAchAction: Action = new Action();
    /**打开宠物界面界面 */
    public onOpenPetAction: Action = new Action();
    /**打开宠物抽奖界面界面 */
    public onOpenRaffleAction: Action = new Action();

    /**当前播放的背景音乐 */
    private currentBgmIndex: number = 1;
    /**背景音乐 */
    private bgmMusics: IMusicElement[] = [];

    /** 当脚本被实例后，会在第一帧更新前调用此函数 */
    protected onStart(): void {
        this.initData();
        this.registerActions();
        this.registerEvents();
    }

    /**初始化数据 */
    private initData(): void {
        this.hudPanel = UI.UIManager.instance.getUI(HUDPanel);
        this.shopModuleC = ModuleManager.getInstance().getModule(ShopModuleC);
        this.achievementModuleC = ModuleManager.getInstance().getModule(AchievementModuleC);
        this.adTips = UI.UIManager.instance.getUI(AdTips);
        this.petPanel = UI.UIManager.instance.getUI(PetPanel);
        this.bgmMusics = GameConfig.Music.getAllElement();
    }


    /**注册事件 */
    private registerActions(): void {
        this.onJumpAction.add(() => {
            this.jump();
        });

        this.hudPanel.onBgmAction.add((isOpenBGM: boolean) => {
            if (isOpenBGM) {
                this.playBGM(0);
            }
            else {
                SoundService.getInstance().stopBGM();
            }
        });

        this.hudPanel.onSwitchBgmAction.add(this.playBGM.bind(this));

        this.onMusicAction.add(() => {
            if (this.hudPanel.mMusicCanvas.visibility == UI.SlateVisibility.SelfHitTestInvisible) return;
            this.hudPanel.mMusicCanvas.visibility = UI.SlateVisibility.SelfHitTestInvisible;
        });

        this.hudPanel.onRebirthAction.add(this.rebirthHome.bind(this));

        this.shopModuleC.onSwitchCameraAction.add((isOpenSkinShop: boolean) => {
            this.hudPanel.mJoystick.resetJoyStick();
            isOpenSkinShop ? this.hudPanel.hide() : this.hudPanel.show();
        });
        this.onAttackAction.add(this.attack.bind(this));
        this.onFlyOrWalkAction.add(() => {
            this.switchToFlyingOrWalking();
        });

        this.onOpenAdsAction.add(this.ads.bind(this));
    }

    /**注册事件 */
    private registerEvents(): void {
        Events.addLocalListener("IsCanFly", this.wingIsCanFly.bind(this));
    }

    protected onEnterScene(sceneType: number): void {
        this.hudPanel.show();
        // this.hudPanel.mAttackMaskBtn.visibility = UI.SlateVisibility.Collapsed;
        this.registerGlobalClickSound();
        this.delayedOperation();
        this.initWeaponData();
        this.initPlayerData();
        this.initGameGuide();
    }

    /**延迟执行的测试用例 */
    private delayedOperation(): void {
        TimeUtil.delaySecond(3).then(() => {
            this.playWaterSound();
            this.playBGM(0);
            if (GlobalData.isHideHeadUI) {
                this.currentPlayer.character.characterName = "";
            }
            if (GlobalData.isOpenTest) {
                UI.UIManager.instance.getUI(Test).show();
            }
        });
    }

    /**全局UI点击音效唯一标识 */
    private uiClickSoundId: string = null;
    /**注册全局点击音效 */
    private registerGlobalClickSound(): void {
        /**全局UI点击音效 */
        Events.addLocalListener("PlayButtonClick", () => {
            if (this.uiClickSoundId) {
                // Console.error("[停止上一次的点击音效]");
                SoundService.getInstance().stopSound(this.uiClickSoundId);
                this.uiClickSoundId = null;
            }
            this.uiClickSoundId = SoundService.getInstance().playSound(GlobalData.uiClickSoundGuid);
        });
    }

    /**播放水声 */
    private playWaterSound(): void {
        let worldPos: Type.Vector[] =
            [
                new Type.Vector(1000, -1435, 50),
                new Type.Vector(1000, -685, 50),
                new Type.Vector(600, -1060, 50),
                new Type.Vector(1360, -1060, 50)
            ];
        for (let i = 0; i < worldPos.length; ++i) {
            SoundService.getInstance().play3DSound(
                GlobalData.waterSoundGuid, worldPos[i], 0, 1);
        }
    }

    /**播放背景音乐 */
    private playBGM(bgmIndex: number): void {
        this.currentBgmIndex = this.currentBgmIndex + bgmIndex;
        if (this.currentBgmIndex > this.bgmMusics.length) {
            this.currentBgmIndex = 1;
        }
        else if (this.currentBgmIndex < 1) {
            this.currentBgmIndex = this.bgmMusics.length;
        }
        let bgmId = this.bgmMusics[this.currentBgmIndex - 1].Guid;
        SoundService.getInstance().playBGM(bgmId);
        this.hudPanel.mMusicText.text = this.bgmMusics[this.currentBgmIndex - 1].Annotation;
        this.achievementModuleC.onExecuteAchievementAction.call(16, 1);
    }

    /**显示时间 */
    public showTime(time: string): void {
        if (!this.hudPanel || !this.hudPanel.mTimeText) return;
        this.hudPanel.mTimeText.text = time;
    }

    public net_rebirthHome(): void {
        this.rebirthHome();
        Tips.show("获得5秒无敌防御");
    }

    /**回家 */
    private rebirthHome(): void {
        let index = Utils.getRandomInteger(0, 3);
        this.currentPlayer.character.worldLocation = GlobalData.homeLocs[index];
        this.currentPlayer.character.worldRotation = GlobalData.homeRots[index];
        this.currentPlayer.character.cameraSystem.cameraWorldTransform.rotation = GlobalData.homeRots[index];
        this.shopModuleC.playEffectAndSoundToPlayer(2);
        // this.hudPanel.mAttackMaskBtn.visibility = UI.SlateVisibility.Collapsed;
    }

    /**随机传送 */
    public randomPortal(): void {
        let index = Utils.getRandomInteger(0, 3);
        this.currentPlayer.character.worldLocation = GlobalData.portalLocs[index];
        this.shopModuleC.playEffectAndSoundToPlayer(2);
        // this.hudPanel.mAttackMaskBtn.visibility = UI.SlateVisibility.Visible;
    }
    private cameraAnchorLen: number = 0;
    private curCameraAnchorLen: number = 0;
    /**初始化游戏引导 */
    private initGameGuide(): void {
        if (this.shopModuleC == null) {
            this.shopModuleC = ModuleManager.getInstance().getModule(ShopModuleC);
        }
        if (this.shopModuleC.getIsFirstGame()) {
            this.cameraAnchorLen = this.locs.length;
            this.guidePanel = UI.UIManager.instance.getUI(GuidePanel);
            this.guidePanel.show();
            this.guidePanel.onNextAction.add(() => {
                if (this.curCameraAnchorLen > this.cameraAnchorLen) return;
                this.nextCamerTransform();
            });
        }
        else {
            this.onOpenAchAction.call();
            this.onOpenPetAction.call();
            this.onOpenSignInAction1.call();
        }
    }
    private locs: Type.Vector[] = [
        new Type.Vector(2430, 1560, 300),
        new Type.Vector(-1000, 1560, 300),
        new Type.Vector(-1926, 2580, 300),
        new Type.Vector(-2000, -570, 330),
        new Type.Vector(2400, 210, 300),
        new Type.Vector(-135, -1930, 280),
        new Type.Vector(-2500, 500, 400),
        new Type.Vector(-2500, -3000, 400),
        new Type.Vector(-15000, 15000, 2000),
        new Type.Vector(-3400, -600, 450),
        new Type.Vector(-9000, 15000, 2500),
        new Type.Vector(-11000, 14000, 500),
    ];
    private rots: Type.Rotation[] = [
        new Type.Rotation(0, -10, 180),
        new Type.Rotation(0, -10, 0),
        new Type.Rotation(0, -10, 10),
        new Type.Rotation(0, -25, 25.5),
        new Type.Rotation(0, 30, 0),
        new Type.Rotation(0, 0, -90),
        new Type.Rotation(0, -45, 180),
        new Type.Rotation(0, -40, 180),
        new Type.Rotation(0, -20, 170),
        new Type.Rotation(0, -10, 180),
        new Type.Rotation(0, -26, 180),
        new Type.Rotation(0, -30, 150),
    ];
    /**玩家身上的相机 */
    private camera: Gameplay.CameraSystem = null;
    /**拿到相机 */
    private get getCamera(): Gameplay.CameraSystem {
        if (this.camera == null) {
            this.camera = this.currentPlayer.character.cameraSystem;
        }
        return this.camera;
    }
    /**下一个游戏视角 */
    private nextCamerTransform(): void {
        if (this.curCameraAnchorLen >= this.cameraAnchorLen) {
            // this.getCamera.attachToGameObject(this.currentPlayer.character);
            this.getCamera.cameraRotationMode = Gameplay.CameraRotationMode.RotationControl;
            this.getCamera.cameraLocationMode = Gameplay.CameraLocationMode.LocationFollow;
            let transform = new Type.Transform();
            transform.location = new Type.Vector(0, 0, 85);
            transform.rotation = new Type.Rotation(0, 0, 0);
            this.getCamera.cameraRelativeTransform = transform;
            this.currentPlayer.character.addMoveInput(this.currentPlayer.character.getForwardVector());
            this.shopModuleC.completeGameGuide();
            this.curCameraAnchorLen++;
            return;
        }
        if (this.curCameraAnchorLen == 0) {
            this.getCamera.cameraRotationMode = Gameplay.CameraRotationMode.RotationFixed;
            this.getCamera.cameraLocationMode = Gameplay.CameraLocationMode.LocationFixed;
        }
        let transform = new Type.Transform();
        transform.location = this.locs[this.curCameraAnchorLen];
        transform.rotation = this.rots[this.curCameraAnchorLen++];
        this.getCamera.cameraRelativeTransform = transform;
    }

    /**本客户端进入游戏同步其他客户端数据 */
    public net_enterGameSnycData(
        wingPlayerIds: number[], wingIds: number[],
        tailEffectplayerIds: number[], tailEffectIds: number[],
        weaponPlayerIds: number[], weaponIds: number[]): void {
        if (wingPlayerIds.length > 0) {
            this.syncWing(wingPlayerIds, wingIds);
        }
        if (tailEffectplayerIds.length > 0) {
            this.snycTailEffect(tailEffectplayerIds, tailEffectIds);
        }
        if (weaponPlayerIds.length < 0) {
            this.syncWeaponData(weaponPlayerIds, weaponIds);
        }
    }

    /**某个客户端玩家离开游戏同步给其他客户端 */
    public net_exitGameSyncData(playerId: number): void {
        this.exitGameDeleteWing(playerId);
        this.exitGameDeletetailEffect(playerId);
        this.exitGameDeleteWeapon(playerId);
    }

    //#region  翅膀
    /**---------------------------------【翅膀】--------------------------------- */
    /**储存所有所有客户端的翅膀 */
    private wingMap: Map<number, number> = new Map<number, number>();
    /**飞行OR行走状态切换的事件 */
    public onFlyOrWalkAction: Action = new Action();

    /**拾取翅膀 */
    public pickUpWing(id: number): void {
        this.achievementModuleC.onExecuteAchievementAction.call(14, 1);
        this.server.net_pickWing(id);
        this.shopModuleC.useWingCloseShopPanel();
        if (this.hudPanel.mFlyCanvas.visibility == UI.SlateVisibility.Collapsed && id > 1) {
            this.onFlyOrWalkAction.call();
            this.hudPanel.mFlyCanvas.visibility = UI.SlateVisibility.SelfHitTestInvisible;
        }
        else if (this.hudPanel.mFlyCanvas.visibility == UI.SlateVisibility.SelfHitTestInvisible && id == 1) {
            this.hudPanel.mFlyCanvas.visibility = UI.SlateVisibility.Collapsed;
        }
    }

    /**拾取翅膀（所有客户端） */
    public net_pickUpWing(playerId: number, id: number): void {
        this.equipWing(playerId, id);
    }

    /**玩家离开游戏删除翅膀 */
    private exitGameDeleteWing(playerId: number): void {
        if (this.wingMap.has(playerId)) {
            EffectService.getInstance().stopEffect(this.wingMap.get(playerId));
            this.wingMap.delete(playerId);
        }
    }

    /**装备翅膀 */
    private async equipWing(playerId: number, id: number): Promise<void> {
        let effectId: number = null;
        if (this.wingMap.has(playerId)) {
            effectId = this.wingMap.get(playerId);
            EffectService.getInstance().stopEffect(effectId);
        }
        let wing = GameConfig.Wing.getElement(id);
        if (wing.WingGuid == null) return;
        let player = await Gameplay.asyncGetPlayer(playerId);
        effectId = EffectService.getInstance().playEffectOnPlayer(wing.WingGuid, player, Gameplay.SlotType.BackOrnamental,
            0, wing.WingOffset, new Type.Rotation(wing.WingRotation), wing.WingScale);
        this.wingMap.set(playerId, effectId);
    }

    /**本客户端同步其他客户端的翅膀数据 */
    private syncWing(wingPlayerIds: number[], wingIds: number[]): void {
        let playerCount = wingPlayerIds.length;
        --playerCount;
        this.equipWing(wingPlayerIds[playerCount], wingIds[playerCount]);
        let intervalId = TimeUtil.setInterval(() => {
            --playerCount;
            if (playerCount < 0) {
                TimeUtil.clearInterval(intervalId);
                return;
            }
            this.equipWing(wingPlayerIds[playerCount], wingIds[playerCount]);
            Console.error("[我看看你执行几次]");
        }, 0.1);
    }

    /**是否可以飞 */
    private isCanFly: boolean = true;
    /**是否可以飞 */
    public get IsCanFly(): boolean {
        return this.isCanFly;
    }
    /**是否可以飞 */
    public set IsCanFly(isCanFly: boolean) {
        this.isCanFly = isCanFly;
    }

    /**是否正在飞行 */
    private isFlying: boolean = false
    /**是否正在飞行 */
    public get IsFlying(): boolean {
        return this.isFlying;
    }
    /**是否正在飞行 */
    public set IsFlying(isFlying: boolean) {
        this.isFlying = isFlying;
    }

    /**切换飞行或行走状态 */
    private switchToFlyingOrWalking(): void {
        this.currentPlayer.character.switchToFlying();
        this.hudPanel.updateFlyCD();
        TimeUtil.delaySecond(GlobalData.wingFlyTime).then(() => {
            this.currentPlayer.character.switchToWalking();
            this.hudPanel.updateFlyButtonCD();
        });
    }

    /**翅膀是否可以使用 */
    private wingIsCanFly(isCanFly: boolean): void {
        this.IsCanFly = isCanFly;
    }
    /**---------------------------------【翅膀】--------------------------------- */
    //#endregion

    //#region 拖尾特效
    /**------------------------------【拖尾特效】------------------------------*/
    /**储存所有所有客户端的拖尾特效 */
    private tailEffectMap: Map<number, number> = new Map<number, number>();

    /**拾取拖尾特效 */
    public pickUptailEffect(id: number): void {
        this.achievementModuleC.onExecuteAchievementAction.call(15, 1);
        this.shopModuleC.useTailCloseShopPanel();
        this.server.net_pickTailEffect(id);
    }

    /**拾取拖尾特效（所有客户端） */
    public net_pickUpTailEffect(playerId: number, id: number): void {
        this.equiptailEffect(playerId, id);
    }

    /**玩家进入游戏同步其他玩家身上的拖尾特效 */
    private snycTailEffect(tailEffectplayerIds: number[], tailEffectIds: number[]): void {
        let playerCount = tailEffectplayerIds.length;
        --playerCount;
        this.equiptailEffect(tailEffectplayerIds[playerCount], tailEffectIds[playerCount]);
        let intervalId = TimeUtil.setInterval(() => {
            --playerCount;
            if (playerCount < 0) {
                TimeUtil.clearInterval(intervalId);
                return;
            }
            this.equiptailEffect(tailEffectplayerIds[playerCount], tailEffectIds[playerCount]);
            Console.error("[我看看你执行几次]");
        }, 0.1);
    }

    /**玩家离开游戏删除拖尾特效 */
    private exitGameDeletetailEffect(playerId: number): void {
        if (this.tailEffectMap.has(playerId)) {
            EffectService.getInstance().stopEffect(this.tailEffectMap.get(playerId));
            this.tailEffectMap.delete(playerId);
        }
    }

    /**装备拖尾特效 */
    private async equiptailEffect(playerId: number, id: number): Promise<void> {
        let effectId: number = null;
        if (this.tailEffectMap.has(playerId)) {
            effectId = this.tailEffectMap.get(playerId);
            EffectService.getInstance().stopEffect(effectId);
        }
        let tail = GameConfig.Tail.getElement(id);
        if (tail.TailGuid == null) return;
        let player = await Gameplay.asyncGetPlayer(playerId);
        effectId = EffectService.getInstance().playEffectOnPlayer(tail.TailGuid, player, Gameplay.SlotType.BackOrnamental,
            0, tail.TailOffset, new Type.Rotation(tail.TailRotation), tail.TailScale);
        this.tailEffectMap.set(playerId, effectId);
    }
    /**------------------------------【拖尾特效】------------------------------*/
    //#endregion

    //#region 攻击
    /**------------------------------【武器-攻击】------------------------------*/
    /**当前客户端所持有的武器ID */
    private weaponId: number = 1;
    /**攻击事件 */
    public onAttackAction: Action = new Action();
    /**更新当前武器CD */
    public onUpdateAttackCD: Action1<number> = new Action1<number>();

    /**初始化武器数据 */
    private initWeaponData(): void {
        let weapon = GameConfig.Weapon.getElement(this.weaponId);
        this.onUpdateAttackCD.call(Number(weapon.WeaponCD));
        this.baseAttackValue = weapon.HurtValue;
    }

    /**攻击 */
    private attack(): void {
        this.server.net_playAniEffSound(this.weaponId);
        let weapons = GameConfig.Weapon.getElement(this.weaponId);
        let attackDelayTime = weapons.AttackDelayTime;
        TimeUtil.delaySecond(Number(attackDelayTime)).then(() => {
            this.attackDetection(weapons);
        });

        this.currentPlayer.character.moveEnable = false;
        TimeUtil.delaySecond(Number(weapons.AttackTime)).then(() => {
            this.currentPlayer.character.moveEnable = true;
        });
    }

    /**攻击检测 */
    private attackDetection(weapons: IWeaponElement): void {
        let goList: Core.GameObject[] = [];
        let attackType = weapons.AttackType;
        switch (attackType) {
            case AttackType.RectangleDetection:
                goList = this.rectangleDetection(weapons);
                break;
            case AttackType.CircularDetection:
                goList = this.circularDetection(weapons);
                break;
            case AttackType.CylindricalDetection:
                goList = this.cylindricalDetection(weapons);
                break;
            default:
                Console.error("attackType = " + attackType + "|[检测类型数据出错了]");
                break;
        }
        Console.error("[len]:" + goList.length);
        if (goList.length == 0) return;
        let playerIds: number[] = [];
        let aiIds: string[] = [];
        for (const go of goList) {
            if (go instanceof Gameplay.Character) {
                let char = go as Gameplay.Character;
                let playerId = char.player.getPlayerID();
                if (char.player.getPlayerID() == this.currentPlayerId) continue;
                playerIds.push(playerId);
                this.flyText(weapons.HurtValue + this.curAttackValue, char.getWorldLocation(), true);
            }
            if (GlobalData.aiGuids.includes(go.guid)) {
                aiIds.push(go.guid);
                this.flyText(weapons.HurtValue + this.curAttackValue, go.getWorldLocation(), true);
            }
        }
        Console.error("[playerIds.Length] " + playerIds.length);
        if (playerIds.length == 0 && aiIds.length == 0) return;
        this.server.net_attackPlayer(playerIds, aiIds, weapons.ImpulseValue, weapons.HurtValue + this.curAttackValue, this.weaponId);
    }
    private exp: number = 0;
    private flyText(damage: number, hitPoint: Type.Vector, isSelf: boolean = false): void {
        let fontColor: Type.LinearColor[] = Utils.randomColor();
        FlyText.instance.showFlyText("-" + damage, hitPoint, fontColor[0], fontColor[1]);
        if (!isSelf) return;
        ExplosiveCoins.instance.explosiveCoins(new Type.Vector(hitPoint.x, hitPoint.y, hitPoint.z / 2), damage, Utils.getRandomInteger(5, 10));
        this.exp++;
        this.hudPanel.mExpProgressBar.currentValue = this.exp / 50;
        if (this.exp >= 50) {
            this.exp = 0;
            this.server.net_addLevel();
            this.setCurAttackValue(50);
            this.setMaxHp(500);
            this.shopModuleC.playEffectAndSoundToPlayer(1);
        }
    }

    public net_FlyText(hp: number): void {
        this.flyText(hp, this.currentPlayer.character.getWorldLocation());
    }

    /**矩形检测 */
    private rectangleDetection(weapons: IWeaponElement): Core.GameObject[] {
        let startLocation = this.currentPlayer.character.worldLocation;
        let forwardVector = this.currentPlayer.character.getForwardVector();
        let forwardMultiply = forwardVector.multiply(weapons.AttackRange[0]);
        let endLocation = new Type.Vector(startLocation.x + forwardMultiply.x, startLocation.y + forwardMultiply.y, startLocation.z + forwardMultiply.z);
        let goList = Gameplay.boxOverlap(startLocation, endLocation, weapons.AttackRange[1], weapons.AttackRange[2], GlobalData.isDebug);
        return goList;
    }

    /**圆形检测 */
    private circularDetection(weapons: IWeaponElement): Core.GameObject[] {
        let playerLoc = this.currentPlayer.character.worldLocation;
        let forwardVector = this.currentPlayer.character.getForwardVector();
        let forwardMultiply = forwardVector.multiply(weapons.AttackRange[0]);
        let startLocation = new Type.Vector(playerLoc.x + forwardMultiply.x, playerLoc.y + forwardMultiply.y, playerLoc.z + forwardMultiply.z + weapons.AttackRange[1]);
        let goList = Gameplay.sphereOverlap(startLocation, weapons.AttackRange[2], GlobalData.isDebug);
        return goList;
    }

    /**圆柱形检测 */
    private cylindricalDetection(weapons: IWeaponElement): Core.GameObject[] {
        let playerLoc = this.currentPlayer.character.worldLocation;
        let forwardVector = this.currentPlayer.character.getForwardVector();
        let forwardMultiply = forwardVector.multiply(weapons.AttackRange[0]);
        let startLocation = new Type.Vector(playerLoc.x + forwardMultiply.x, playerLoc.y + forwardMultiply.y, playerLoc.z + forwardMultiply.z);
        let goList = Gameplay.cylinderOverlap(startLocation, weapons.AttackRange[1], weapons.AttackRange[2], GlobalData.isDebug);
        return goList;
    }

    /**播放攻击动画、特效、音效（服务端同步给所有客户端执行某个客户端的攻击表现） */
    public net_playAniEffSound(playerId: number, weaponId: number): void {
        let player = Gameplay.getPlayer(playerId);
        let weapons = GameConfig.Weapon.getElement(weaponId);

        if (!weapons.AttackAnimationId) return;

        player.character.playAnimation(weapons.AttackAnimationId);
        let startLocation = player.character.worldLocation;
        let forwardVector = player.character.getForwardVector();
        let forwardMultiply = forwardVector.multiply(weapons.EffectOffset);
        let offset = new Type.Vector(startLocation.x + forwardMultiply.x, startLocation.y + forwardMultiply.y, startLocation.z + forwardMultiply.z);
        let tmpRot = new Type.Rotation(forwardVector, Type.Vector.zero);
        let rot = new Type.Rotation(tmpRot.x + weapons.EffectRot.x, tmpRot.y + weapons.EffectRot.y, tmpRot.z + weapons.EffectRot.z);
        TimeUtil.delaySecond(Number(weapons.AttackDelayTime)).then(async () => {
            EffectService.getInstance().playEffectAtLocation(
                weapons.AttackEffectId,
                offset,
                1,
                rot,
                weapons.EffectScale
            );
            SoundService.getInstance().play3DSound(weapons.AttackSound, player.character);
        });
    }

    /**播放受击特效 */
    public net_playHitEffect(playerIds: number[], weaponId: number): void {
        let weapon = GameConfig.Weapon.getElement(weaponId);
        for (const playerId of playerIds) {
            let player = Gameplay.getPlayer(playerId);
            EffectService.getInstance().playEffectOnPlayer(
                weapon.HitEffect,
                player,
                Gameplay.SlotType.Root,
                1,
                weapon.HitEffectOffset,
                new Type.Rotation(weapon.HitEffectRot),
                weapon.HitEffectScale
            );
            if (weapon.HitSound == null) continue;
            SoundService.getInstance().play3DSound(
                weapon.HitSound,
                player.character,
                1,
                10000
            );
        }
    }
    //#endregion

    //#region 武器拾取
    /**每个客户端都存储所有玩家的武器 */
    private weaponModelMap: Map<number, Core.GameObject> = new Map<number, Core.GameObject>();

    /**拾取武器 */
    public pickUpWeapon(id: number): void {
        if (this.weaponId == id) return;
        this.weaponId = id;
        let weapon = GameConfig.Weapon.getElement(id);
        this.onUpdateAttackCD.call(Number(weapon.WeaponCD));
        this.baseAttackValue = weapon.HurtValue;
        this.hudPanel.mAttackText.text = "攻击力：" + (this.baseAttackValue + this.curAttackValue);
        this.achievementModuleC.onExecuteAchievementAction.call(12, 1);
        this.shopModuleC.useWeaponCloseShopPanel();
        this.server.net_pickUpWeapon(id);
    }

    /**拾取武器（服务端通知所有客户端） */
    public net_pickUpWeapon(playerId: number, id: number): void {
        this.destoryWeapon(playerId);
        this.spawnWeapon(playerId, id);
    }

    /**进入房间的玩家同步其他玩家所持有武器数据(服务端通知本客户端) */
    private syncWeaponData(weaponPlayerIds: number[], weaponIds: number[]): void {
        if (weaponPlayerIds.length == 0) return;
        for (let i = 0; i < weaponPlayerIds.length; ++i) {
            let player = Gameplay.getPlayer(weaponPlayerIds[i]);
            let playerId = player.getPlayerID();
            this.spawnWeapon(playerId, weaponIds[i]);
        }
    }

    /**离开房间的玩家同步其他玩家所持有武器数据(服务端通知所有客户端) */
    private exitGameDeleteWeapon(playerId: number): void {
        this.destoryWeapon(playerId);
    }

    /**销毁武器 */
    private destoryWeapon(playerId: number): void {
        if (this.weaponModelMap.has(playerId)) {
            Extension.GameObjPool.getInstance().despawn(this.weaponModelMap.get(playerId));
            this.weaponModelMap.delete(playerId);
        }
    }

    /**生成武器 */
    private spawnWeapon(playerId: number, id: number): void {
        let modelGuid = GameConfig.Weapon.getElement(id).WeaponGuid;
        if (!modelGuid) return;
        let weaponModel = Extension.GameObjPool.getInstance().spawn(modelGuid);
        weaponModel.ready().then(async () => {
            let player = await Gameplay.asyncGetPlayer(playerId);
            player.character.attach(weaponModel, Gameplay.SlotType.RightHand);
            weaponModel.setRelativeLocation(Type.Vector.zero);
            weaponModel.setRelativeRotation(Type.Rotation.zero);
            weaponModel.setWorldScale(Type.Vector.one);
            this.weaponModelMap.set(playerId, weaponModel);
            Console.error("playerId = " + playerId + " 的玩家已使用guid = " + modelGuid + " 的武器");
        });
    }
    /**------------------------------【武器】------------------------------*/
    //#endregion

    //#region 属性
    private ads(): void {
        if (GlobalData.isOpenIAA) {
            this.adTips.showAdTips(1, AdType.AdsReward);
        }
        else {
            this.adsReward();
        }
    }
    public adsReward(): void {
        let index = Utils.getRandomInteger(0, 4);
        switch (index) {
            case 0:
                this.setCurAttackValue(100);
                break;
            case 1:
                this.setMaxHp(500);
                break;
            case 2:
                this.setMaxMoveSpeed(25);
                break;
            case 3:
                this.setMaxFlySpeed(25);
                break;
            case 4:
                this.setMaxJumpHeight(25);
                break;
            default:
                break;
        }
        this.achievementModuleC.ach(1);
        this.server.net_addLevel();
        this.shopModuleC.playEffectAndSoundToPlayer(1);
    }
    public firstGame(): void {
        this.server.net_addLevel1();
        this.shopModuleC.playEffectAndSoundToPlayer(1);
    }
    public firstGame2(): void {
        this.server.net_addLevel2();
        this.shopModuleC.playEffectAndSoundToPlayer(1);
    }
    public addLv(lv: number): void {
        this.server.net_addLevel3(lv);
        this.shopModuleC.playEffectAndSoundToPlayer(1);
    }
    public net_killAch(): void {
        this.achievementModuleC.onExecuteAchievementAction.call(5, 1);
    }
    private maxHp: number = 100;
    private baseAttackValue: number = 0;
    private curAttackValue: number = 0;
    private curMaxMoveSpeed: number = 0;//450
    private curMaxFlySpeed: number = 0;//800
    private curMaxJumpHeight: number = 0;//100
    /**初始化玩家数据 */
    private initPlayerData(): void {
        this.curMaxMoveSpeed = this.currentPlayer.character.maxWalkSpeed;
        this.curMaxFlySpeed = this.currentPlayer.character.maxFlySpeed;
        this.curMaxJumpHeight = this.currentPlayer.character.maxJumpHeight;
        this.maxHp = this.data.maxHp;
        this.curAttackValue = this.data.hurt;
        this.initPlayerHUDPanel();
    }

    /**初始化HUDPanel */
    private initPlayerHUDPanel(): void {
        this.hudPanel.mHpText.text = "最大生命值：" + this.maxHp;
        this.hudPanel.mAttackText.text = "攻击力：" + (this.baseAttackValue + this.curAttackValue);
        this.hudPanel.mMoveSpeedText.text = "移动速度：" + this.curMaxMoveSpeed;
        this.hudPanel.mFlySpeedText.text = "飞行速度：" + this.curMaxFlySpeed;
        this.hudPanel.mJumpHeightText.text = "跳跃高度：" + this.curMaxJumpHeight;
    }

    /**设置最大血量 */
    public setMaxHp(hpValue: number): void {
        // if (this.maxHp >= 999) return;
        this.maxHp += hpValue;
        this.hudPanel.mHpText.text = "最大生命值：" + this.maxHp;
        this.shopModuleC.playEffectAndSoundToPlayer(3);
        this.server.net_setMaxHp(this.maxHp);
    }

    /**设置当前血量 */
    public setCurHp(curHp: number): void {
        this.shopModuleC.playEffectAndSoundToPlayer(3);
        this.server.net_setCurHp(curHp);
    }

    /**设置当前攻击力 */
    public setCurAttackValue(curAttackValue: number): void {
        // if (this.curAttackValue >= 999) return;
        this.curAttackValue += curAttackValue;
        this.hudPanel.mAttackText.text = "攻击力：" + (this.baseAttackValue + this.curAttackValue);
        this.shopModuleC.playEffectAndSoundToPlayer(3);
        this.server.net_setCurAttackValue(this.curAttackValue);
    }

    /**设置最大移动速度 */
    public setMaxMoveSpeed(addMoveSpeed: number): void {
        if (this.curMaxMoveSpeed >= 999) return;
        this.curMaxMoveSpeed += addMoveSpeed;
        this.hudPanel.mMoveSpeedText.text = "移动速度：" + this.curMaxMoveSpeed;
        this.currentPlayer.character.maxWalkSpeed = this.curMaxMoveSpeed;
        this.shopModuleC.playEffectAndSoundToPlayer(3);
    }

    /**设置最大飞行速度 */
    public setMaxFlySpeed(addFlySpeed: number): void {
        if (this.curMaxFlySpeed >= 1500) return;
        this.curMaxFlySpeed += addFlySpeed;
        this.hudPanel.mFlySpeedText.text = "飞行速度：" + this.curMaxFlySpeed;
        this.currentPlayer.character.maxFlySpeed = this.curMaxFlySpeed;
        this.shopModuleC.playEffectAndSoundToPlayer(3);
    }

    /**设置最大跳跃高度 */
    public setMaxJumpHeight(addJumpHeight: number): void {
        if (this.curMaxJumpHeight >= 999) return;
        this.curMaxJumpHeight += addJumpHeight;
        this.hudPanel.mJumpHeightText.text = "跳跃高度：" + this.curMaxJumpHeight;
        this.currentPlayer.character.maxJumpHeight = this.curMaxJumpHeight;
        this.shopModuleC.playEffectAndSoundToPlayer(3);
    }
    //#endregion

    //#region jump
    private currentJumpTime: number = 0;
    private jumpAnimationId: string = "150691";
    private girlJumpSoundId: string = "101208";
    private boyJumpSoundId: string = "121734";
    private jump(): void {
        if (this.currentPlayer.character.isJumping && this.currentJumpTime >= 2) return;
        if (!this.currentPlayer.character.isJumping && this.currentJumpTime >= 2) this.currentJumpTime = 0;
        this.currentJumpTime++;

        if (this.currentJumpTime == 2) {
            this.currentPlayer.character.jump();
            this.currentPlayer.character.playAnimation(this.jumpAnimationId, 1);
            let soundId = this.isGirl() ? this.girlJumpSoundId : this.boyJumpSoundId;
            SoundService.getInstance().play3DSound(soundId, this.currentPlayer.character);
        } else {
            this.currentPlayer.character.jump();
        }
    }

    private isGirl(): boolean {
        let v2 = Gameplay.getCurrentPlayer().character.setAppearance(Gameplay.HumanoidV2);
        if (v2.getSomatotype() == Gameplay.SomatotypeV2.AnimeFemale
            || v2.getSomatotype() == Gameplay.SomatotypeV2.LowpolyAdultFemale
            || v2.getSomatotype() == Gameplay.SomatotypeV2.RealisticAdultFemale
            || v2.getSomatotype() == Gameplay.SomatotypeV2.CartoonyFemale) return true;
        return false;
    }
    //#endregion
}

enum AttackType {
    /**矩形检测 */
    RectangleDetection = 1,
    /**圆形检测 */
    CircularDetection = 2,
    /**圆柱形检测 */
    CylindricalDetection = 3,
}