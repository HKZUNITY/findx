﻿import Console from "../../Tools/Console";
import { FlyText } from "../../common/FlyText";
import { IBlockingVolumeElement } from "../../config/BlockingVolume";
import { GameConfig } from "../../config/GameConfig";
import LevelPanel_Generate from "../../ui-generate/module/PlayerModule/LevelPanel_generate";
import ShopModuleC from "../ShopModule/ShopModuleC";

export class PlayerLevelData extends Subdata {
    @Decorator.saveProperty
    public cleareds: number[] = [];

    protected initDefaultData(): void {
        this.cleareds = [];
    }

    public saveCleared(cleared: number): void {
        if (this.cleareds.includes(cleared)) return;
        this.cleareds.push(cleared);
    }
}

export class PlayerModuleC extends ModuleC<PlayerModuleS, PlayerLevelData> {
    private shopModuleC: ShopModuleC = null;
    private blockingVolumeElements: IBlockingVolumeElement[] = [];
    protected onStart(): void {
        this.shopModuleC = ModuleManager.getInstance().getModule(ShopModuleC);
        this.shopModuleC.onPlayerLevelAction.add((lv: number) => {
            this.currentLv = lv;
            this.updateBlockingVolume();
        });
    }

    private currentLv: number = 0;
    protected onEnterScene(sceneType: number): void {
        if (!this.shopModuleC) {
            this.shopModuleC = ModuleManager.getInstance().getModule(ShopModuleC);
        }
        this.currentLv = this.shopModuleC.getLevel();
        this.initDatas();
    }

    private allTriggers: Gameplay.Trigger[] = [];
    private allBlockingVolumes: Gameplay.BlockingVolume[] = [];
    private allLevelPanels: LevelPanel_Generate[] = [];
    private async initDatas(): Promise<void> {
        this.blockingVolumeElements = GameConfig.BlockingVolume.getAllElement();
        for (let i = 0; i < this.blockingVolumeElements.length; ++i) {
            let blockingVolumeElement = this.blockingVolumeElements[i];
            this.allLv.push(blockingVolumeElement.Lv);
            if (!blockingVolumeElement.TriggerGuid) continue;
            let trigger = await Core.GameObject.asyncFind(blockingVolumeElement.TriggerGuid) as Gameplay.Trigger;
            if (trigger) {
                this.allTriggers.push(trigger);
                // if (this.currentLv < blockingVolumeElement.Lv) {
                trigger.onEnter.add(this.onEnterTrigger.bind(this, blockingVolumeElement.Lv, i));
                // } else {
                //     trigger.destroy();
                //     this.allTriggers[i] = null;
                // }
            }
            let blockingVolume = await Core.GameObject.asyncFind(blockingVolumeElement.BlockingVolumeGuid) as Gameplay.BlockingVolume;
            if (blockingVolume) {
                this.allBlockingVolumes.push(blockingVolume);
                if (this.currentLv >= blockingVolumeElement.Lv) {
                    blockingVolume.setCurrentPlayerPassable(this.currentPlayerId, true);
                    // blockingVolume.destroy();
                    this.allBlockingVolumes[i] = null;
                } else {
                    blockingVolume.setCurrentPlayerPassable(this.currentPlayerId, false);
                }
            }
            let levelPanel = UI.UIManager.instance.create(LevelPanel_Generate);
            let levelPanelWidget = await Core.GameObject.asyncFind(blockingVolumeElement.WorldUIGuid) as Gameplay.UIWidget;
            if (levelPanelWidget) {
                levelPanelWidget.setTargetUIWidget(levelPanel.uiWidgetBase);
                levelPanelWidget.widgetSpace = Gameplay.WidgetSpaceMode.World;
                this.allLevelPanels.push(levelPanel);
                if (this.data.cleareds.includes(blockingVolumeElement.ID)) {
                    levelPanel.mTextBlock.text = "第" + (i + 1) + "已通关";
                } else {
                    if (this.currentLv >= blockingVolumeElement.Lv) {
                        levelPanel.mTextBlock.text = "第" + (i + 1) + "关已解锁";
                    } else {
                        levelPanel.mTextBlock.text = blockingVolumeElement.Lv + "级解锁";
                    }
                }
            }
            Console.error("[hkz] - i = " + i);
        }
    }
    private levelLoc: Type.Vector[] = [
        new Type.Vector(198139, 37965, 64390),
        new Type.Vector(198139, -10699, 64390),
        new Type.Vector(198139, 3315, 64390),
        new Type.Vector(198139, 14030, 64390),
        new Type.Vector(198139, 23845, 64390)
    ];
    private onEnterTrigger(lv: number, i: number, character: Gameplay.Character): void {
        if (character != Gameplay.getCurrentPlayer().character) return;
        if (this.currentLv >= lv) {
            this.currentPlayer.character.setWorldLocation(this.levelLoc[i]);
        } else {
            FlyText.instance.showFlyText("等级不足", this.currentPlayer.character.getWorldLocation());
        }
    }

    private allLv: number[] = [];
    private updateBlockingVolume(): void {
        for (let i = 0; i < this.allLv.length; ++i) {
            if (!this.allBlockingVolumes[i]) continue;
            if (this.currentLv >= this.allLv[i]) {
                this.allBlockingVolumes[i].setCurrentPlayerPassable(this.currentPlayerId, true);
                // this.allBlockingVolumes[i].destroy();
                this.allBlockingVolumes[i] = null;
                // this.allTriggers[i].onEnter.remove(this.onEnterTrigger.bind(this));
                // this.allTriggers[i].destroy();
                // this.allTriggers[i] = null;
                this.allLevelPanels[i].mTextBlock.text = "第" + (i + 1) + "关已解锁";
            }
        }
    }

    private updateLevelPanel(id: number): void {
        if (this.data.cleareds.includes(id)) return;
        this.allLevelPanels[id - 1].mTextBlock.text = "第" + id + "关已通关";
        this.saveCleared(id);
    }

    public saveCleared(cleared: number): void {
        this.server.net_saveCleared(cleared);
    }
}

export class PlayerModuleS extends ModuleS<PlayerModuleC, PlayerLevelData> {

    protected onStart(): void {

    }

    public net_saveCleared(cleared: number): void {
        this.currentData.saveCleared(cleared);
    }
}