﻿import Console from "../../Tools/Console";
import NPCBar_Generate from "../../ui-generate/module/NPCModule/NPCBar_generate";

@Core.Class
export default class NPCBar extends Core.Script {
    @Core.Property({ replicated: true, onChanged: "onHpChange" })
    public maxHp: number = 0;
    @Core.Property({ replicated: true, onChanged: "onHpChange" })
    public hp: number = 0;
    @Core.Property({ replicated: true, onChanged: "onNameChange" })
    private _hpBarUI: NPCBar_Generate;
    private _hpBarWidget: Gameplay.UIWidget;
    private _isInit = false;

    /** 当脚本被实例后，会在第一帧更新前调用此函数 */
    protected onStart(): void {
        if (SystemUtil.isClient()) {
            Console.log("初始化血条UI");
            this.init();
        }
    }

    private async init() {
        this._hpBarUI = UI.UIManager.instance.create(NPCBar_Generate);
        this._hpBarWidget = await Gameplay.GameObject.asyncSpawn<Gameplay.UIWidget>({ guid: "UIWidget", replicates: false });
        this._hpBarWidget.setTargetUIWidget(this._hpBarUI.uiWidgetBase);
        this._hpBarWidget.widgetSpace = Gameplay.WidgetSpaceMode.OverheadUI;
        let character = this.gameObject as Gameplay.NPC;
        this._hpBarWidget.attachToGameObject(character.getHeadUIWidget());
        this._hpBarWidget.relativeLocation = Vector.up.multiply(10);
        this._isInit = true;
        this.onHpChange();
    }

    private onHpChange() {
        if (!this._isInit) {
            return;
        }
        this._hpBarUI.mProgressBar.percent = this.hp / this.maxHp;
        this._hpBarUI.mHpTextBlock.text = `${this.hp}/${this.maxHp}`;
    }

    protected onDestroy(): void {
        this._hpBarUI?.destroy();
        this._hpBarWidget?.destroy();
    }
}