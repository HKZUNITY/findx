﻿import Console from "../../../../../Tools/Console";
import { GameConfig } from "../../../../../config/GameConfig";
import { TrampolineConfig } from "../../../../../config/Trampoline";

/*
 * @Author: 侯凯召
 * @QQ邮箱: 3046916186@qq.com
 * @Date: 2023-01-29 16:42:08
 * @LastEditors: 穿迷彩服的鲨鱼
 * @LastEditTime: 2023-02-03 11:50:19
 * @Description: 蹦床
 * @FilePath: \Demo\JavaScripts\prefab\Trampoline\Trampoline.ts
 */
@Core.Class
export default class Trampoline extends Core.Script {
    @Core.Property({ group: "脚本属性", displayName: "预加载资源", onChangedInEditor: "onPreloadAssetsChangedInEditor" })
    private preloadAssets = "";

    @Core.Property({ displayName: "基础跳跃冲量", group: "脚本属性" })
    private baseFallMultiplyNum: number = 2000;

    @Core.Property({ displayName: "基础冲击数", group: "脚本属性" })
    private baseMultiplyNum: number = 300;

    @Core.Property({ displayName: "冲击半径", group: "脚本属性" })
    private impactRadius: number = 100;

    private trampoline: TrampolineConfig = null;
    private trampolineLen: number = 0;
    /**冲击时要显示的UI */
    private impactUI: string = "6A16F210463EEA916B51EC9E36852260";

    /** 当脚本被实例后，会在第一帧更新前调用此函数 */
    protected onStart(): void {
        this.trampoline = GameConfig.Trampoline;
        this.trampolineLen = this.trampoline.getAllElement().length;
        if (Util.SystemUtil.isClient()) {
            this.onStartC();
        }
        if (Util.SystemUtil.isServer()) {
            this.onStartS();
        }
    }

    /**
     * 周期函数 每帧执行
     * 此函数执行需要将this.useUpdate赋值为true
     * @param dt 当前帧与上一帧的延迟 / 秒
     */
    protected onUpdate(dt: number): void {
        if (Util.SystemUtil.isClient()) {
            this.onUpdateC(dt);
        }
        if (Util.SystemUtil.isServer()) {
            this.onUpdateS(dt);
        }
    }

    /** 当预加载资源改动的时候自动调用此函数 */
    public onPreloadAssetsChangedInEditor() {
        let assets: string = ""

        for (let key in TrampolineRescourse) {
            let keyToAny: any = key;
            if (isNaN(keyToAny)) {
                let trampolineRescourse: any = TrampolineRescourse[key];
                let trampolineRescourseEnum: TrampolineRescourse = trampolineRescourse;
                assets = assets + trampolineRescourseEnum + ",";
            }
        }
        assets = assets.substring(0, assets.length - 1);
        this.preloadAssets = assets;
    }

    /**------------------------------------------- 客户端 ------------------------------------------------ */
    private playerC: Gameplay.Player = null;
    /**需要变化的模型 */
    private trampolineModelsC: Gameplay.GameObject[] = [];
    private ignoreAreaC: OBB[] = [];
    private capsuleRadius = 30;

    /**玩家世界UIMap */
    private playersRadiusUI: Map<number, Core.GameObject> = new Map<number, Core.GameObject>();

    /**客户端的onStart */
    private onStartC(): void {
        this.initDataC();
        this.registerEventsC();
        this.useUpdate = true;
    }

    /**初始化数据（客户端） */
    private async initDataC(): Promise<void> {
        // this.loadRescourseC();
        this.findGameObjectsC();
        this.playerC = await Gameplay.asyncGetCurrentPlayer();
        this.playerC.ready().then(() => {
            this.playerC.character.airControl = 0.5;
            Console.error("[更新下落控制成功]");
        });
    }

    /**加载资源（客户端） */
    private async loadRescourseC(): Promise<void> {
        for (let key in TrampolineRescourse) {
            let keyToAny: any = key;
            if (isNaN(keyToAny)) {
                let launcherRescourse: any = TrampolineRescourse[key];
                let launcherRescourseEnum: TrampolineRescourse = launcherRescourse;
                await this.downloadRes(launcherRescourseEnum);
                Console.error("launcherRescourseEnum--" + launcherRescourseEnum);
            }
        }
    }

    /**根据object的guid find到它（客户端） */
    private async findGameObjectsC(): Promise<void> {
        if (this.trampolineLen > 0) {
            for (let i = 0; i < this.trampolineLen; ++i) {
                let trampolineModel = await Core.GameObject.asyncFind(this.trampoline.getElement(i + 1).ModelGuid);
                this.trampolineModelsC.push(trampolineModel);
                this.createShakeOBBC(trampolineModel, i);
            }
        }
    }

    /**创建蹦床中间区域判定(客户端) */
    private createShakeOBBC(trampolineModel: Core.GameObject, index: number) {
        let PointX = trampolineModel.worldScale.x * 100 + this.capsuleRadius;
        let PointY = trampolineModel.worldScale.y / 1.5 * 100 + this.capsuleRadius;
        let center = new Type.Vector2(trampolineModel.worldLocation.x, trampolineModel.worldLocation.y);
        this.ignoreAreaC[index] = new OBB(center, trampolineModel.getForwardVector(), trampolineModel.getRightVector(), PointX, PointY);
    }

    /**注册事件&监听事件（客户端） */
    private registerEventsC(): void {
        Events.addServerListener(ListenerEventsType.ServerToAllClient_Shake, this.modelShakeVFXAndSFXC.bind(this));

        Events.addServerListener(ListenerEventsType.ServerToAllClient_ShowRadiusUI, this.showRadiusUIC.bind(this));
        Events.addServerListener(ListenerEventsType.ServerToAllClient_HideRadiusUI, this.hideRadiusUIC.bind(this));
    }

    /**客户端的Update */
    private onUpdateC(dt: number): void {
        this.playersRadiusUI.forEach((value, key) => {
            let player = Gameplay.getPlayer(key);
            if (player.character.velocity.z >= 0) return;
            this.lineTraceCheck(player, value);
        })
    }

    /**射线检测更新世界UI位置(客户端) */
    private lineTraceCheck(player: Gameplay.Player, radiusUI: Core.GameObject): void {
        const downVec = player.character.getUpVector().clone().multiply(-1);
        const loc = player.character.worldLocation;
        const goArr = Gameplay.lineTrace(loc, loc.clone().add(downVec.multiply(500000)), true, false);
        for (let index = 0; index < goArr.length; index++) {
            const element = goArr[index];
            // Console.error("[element]:" + element.gameObject.name);
            if ((element.gameObject instanceof Gameplay.Character)) continue;
            if (element.gameObject.name == "BP_MWSysUIWidget") continue;
            if (element.gameObject.name == "世界UI") continue;
            if (element.gameObject.name == "蹦床") {
                if (radiusUI.getVisibility())
                    radiusUI.setVisibility(Type.PropertyStatus.Off);
                return;
            };
            if (!radiusUI.getVisibility())
                radiusUI.setVisibility(Type.PropertyStatus.On);
            radiusUI.worldLocation = element.location.clone().add(Type.Vector.up.multiply(10));
            return;
        }
    }

    /**模型震动时的视觉和听觉效果（客户端） */
    private modelShakeVFXAndSFXC(playerId: number, triggerIndex: number): void {
        this.playSoundAndEffectC(playerId, triggerIndex);
        this.modelShakeC(triggerIndex);
    }

    /**播放音效和特效（客户端） */
    private playSoundAndEffectC(playerId: number, triggerIndex: number): void {
        if (this.playerC.getPlayerID() == playerId) {
            Service.SoundService.getInstance().playSound(TrampolineRescourse.TrampolineSound, 1, 100);
        }
        else {
            Service.SoundService.getInstance().play3DSound(TrampolineRescourse.TrampolineSound,
                this.trampolineModelsC[triggerIndex].getWorldLocation(), 1, 100);
        }
    }

    /**玩家进入触发器震动模型（客户端） */
    private modelShakeC(triggerIndex: number): void {
        let baseScale = this.trampolineModelsC[triggerIndex].worldScale;
        let curPlayerPos = this.playerC.character.worldLocation;
        let playerLoc2 = new Type.Vector2(curPlayerPos.x, curPlayerPos.y);
        if (this.ignoreAreaC[triggerIndex].containsPoint(playerLoc2)) {
            new Util.TweenUtil.Tween({ time: 0 })
                .to({ time: 1 }, 1000)
                .onUpdate((obj) => {
                    let z = this.shakeFunc(obj.time, 100, 6, 5) * 8;
                    let worldScale = new Type.Vector(baseScale.x, baseScale.y, baseScale.z + z);
                    this.trampolineModelsC[triggerIndex].worldScale = worldScale;
                })
                .start();
        } else {
            let curTrampolinePos = this.trampolineModelsC[triggerIndex];
            let modelLoc2 = new Type.Vector2(curTrampolinePos.worldLocation.x, curTrampolinePos.worldLocation.y);
            let loc = modelLoc2.subtract(playerLoc2);
            loc = loc.normalized;
            let changeRot = new Type.Rotation(new Type.Vector(loc.x, loc.y, 0));
            new Util.TweenUtil.Tween({ time: 0 })
                .to({ time: 1 }, 1000)
                .onUpdate((obj) => {
                    let x = this.shakeFunc(obj.time, 100, 6, 5) * 100 * changeRot.y;
                    let y = this.shakeFunc(obj.time, 100, 6, 5) * 100 * changeRot.x;
                    let rot = new Type.Rotation(x, y, changeRot.z);
                    this.trampolineModelsC[triggerIndex].setRelativeRotation(rot);
                })
                .start();
        }
    }

    /**显示冲击指示范围UI（客户端） */
    private showRadiusUIC(playerId: number, number: number): void {
        if (!this.playersRadiusUI.has(playerId)) this.createRadiusUIC(playerId);
        let radiusUI = this.playersRadiusUI.get(playerId);
        radiusUI.worldScale = Type.Vector.one.multiply(number * 2 / 100);
        radiusUI.setVisibility(Type.PropertyStatus.Off);
    }

    /**Create世界UI并刷新（客户端） */
    private createRadiusUIC(playerId: number): void {
        let uiWidget = Extension.GameObjPool.getInstance().spawn("UIWidget") as Gameplay.UIWidget;
        uiWidget.setUI(this.impactUI);
        uiWidget.pivot = Type.Vector2.one.multiply(0.5);
        uiWidget.drawSize = Type.Vector2.one.multiply(100);
        uiWidget.setRelativeRotation(new Type.Rotation(0, 90, 0));
        uiWidget.widgetSpace = Gameplay.WidgetSpaceMode.World;
        uiWidget.setCollision(Type.PropertyStatus.Off);
        uiWidget.refresh();
        this.playersRadiusUI.set(playerId, uiWidget);
    }

    /**隐藏玩家身上的世界UI（客户端） */
    private hideRadiusUIC(playerId: number): void {
        let radiusUI = this.playersRadiusUI.get(playerId);
        if (!radiusUI) return;
        Extension.GameObjPool.getInstance().despawn(radiusUI);
        this.playersRadiusUI.delete(playerId);
    }
    /**------------------------------------------- 客户端 ------------------------------------------------ */

    /**------------------------------------------- 服务端 ------------------------------------------------ */
    /**延迟触发（避免重复执行） */
    private cantEnterPlayerIdS: Set<number> = new Set();
    /**触发器 */
    private triggersS: Gameplay.Trigger[] = [];
    /**玩家跳跃时间 */
    private playersJumpTimeS: Map<number, number> = new Map();
    /**计算玩家是否触地面 */
    private playerFlyAndFallMap: Map<number, boolean> = new Map<number, boolean>();
    /**飞行玩家的掉落特效 */
    private playerFallEffects: Map<number, number> = new Map<number, number>();
    /**悬空玩家的拖尾特效 */
    private playerTailEffectMap: Map<number, number[]> = new Map<number, number[]>();
    private playersImpactRadius: Map<number, number> = new Map();
    private ignoreAreaS: OBB[] = [];

    /**服务端的onStart */
    private onStartS(): void {
        this.initDataS();
        this.registerEventsS();
        this.useUpdate = true;
    }

    /**初始化数据（服务端） */
    private async initDataS(): Promise<void> {
        await this.findGameObjectsS();
        this.bindTriggerS();
    }

    /**注册事件&监听事件（服务端） */
    private registerEventsS(): void {
        Events.addPlayerLeftListener((player) => {
            let playerId = player.getPlayerID();
            if (this.playerFlyAndFallMap.has(playerId)) {
                this.playerFlyAndFallMap.delete(playerId);
            }
            if (this.playersJumpTimeS.has(playerId)) {
                this.playersJumpTimeS.delete(playerId);
            }
            if (this.playersImpactRadius.has(playerId)) {
                this.playersImpactRadius.delete(playerId);
            }
        });
    }

    /**根据object的guid find到它（服务端） */
    private async findGameObjectsS(): Promise<void> {
        if (this.trampolineLen == 0) return;
        for (let i = 0; i < this.trampolineLen; ++i) {
            let trigger = (await Core.GameObject.asyncFind(this.trampoline.getElement(i + 1).TriggerGuid)) as Gameplay.Trigger;
            this.triggersS.push(trigger);
            this.createTouchOBBS(trigger, i);
        }
    }

    /**创建蹦床中间区域判定(客户端) */
    private createTouchOBBS(trigger: Gameplay.Trigger, index: number) {
        let PointX = trigger.worldScale.x * 50 + this.capsuleRadius;
        let PointY = trigger.worldScale.y * 50 + this.capsuleRadius;
        let center = new Type.Vector2(trigger.worldLocation.x, trigger.worldLocation.y);
        this.ignoreAreaS[index] = new OBB(center, trigger.getForwardVector(), trigger.getRightVector(), PointX, PointY);
    }

    /**绑定触发器（服务端） */
    private bindTriggerS(): void {
        if (this.triggersS.length == 0) return;
        for (let i = 0; i < this.triggersS.length; ++i) {
            this.triggersS[i].onEnter.add((go) => {
                this.onEnterTriggerS(go, i);
            });
        }
    }

    /**进入触发器(服务端) */
    private onEnterTriggerS(go: Core.GameObject, triggerIndex: number): void {
        if (!(go instanceof Gameplay.Character)) return;
        let player = (go as Gameplay.Character).player;
        if (player.character.movementState == Gameplay.MovementMode.Fly) return;
        let playerId = player.getPlayerID();

        if (this.cantEnterPlayerIdS.has(playerId)) return;
        this.cantEnterPlayerIdS.add(playerId);
        Util.TimeUtil.delayExecute(() => {
            this.cantEnterPlayerIdS.delete(playerId);
        }, 20)
        Events.dispatchToClient(player, ListenerEventsType.ServerToAllClient_ShowJumpRecordUI, this.triggersS[triggerIndex].worldLocation.z);
        this.modelVisualEffectS(playerId, triggerIndex);
        this.playerFlyS(player);
        this.showRadiusUIS(playerId);
    }

    /**广播给房间内得客户端显示正在使用蹦床玩家得落点世界UI（服务端） */
    private showRadiusUIS(playerId: number): void {
        let num = this.impactRadius + 100 * this.playersJumpTimeS.get(playerId)
        this.playersImpactRadius.set(playerId, num);
        Events.dispatchToAllClient(ListenerEventsType.ServerToAllClient_ShowRadiusUI, playerId, num);
    }

    /**模型视觉效果（服务端） */
    private modelVisualEffectS(playerId: number, triggerIndex: number): void {
        Events.dispatchToAllClient(ListenerEventsType.ServerToAllClient_Shake, playerId, triggerIndex);
    }

    /**玩家进入触发器玩家原地起飞（服务端） */
    private playerFlyS(player: Gameplay.Player): void {
        let playerId = player.getPlayerID();
        let value = this.playersJumpTimeS.get(playerId);
        value = value ? value : 0;
        this.addPlayerImpulse(player, value);
        setTimeout(() => {
            this.playerFlyAndFallMap.set(playerId, false);
        }, 500);
        this.playersJumpTimeS.set(playerId, value + 1);
    }

    /**添加向上的冲量（服务端） */
    @Core.Function(Core.Client)
    private addPlayerImpulse(player: Gameplay.Player, jumpTime: number) {
        let multiplyNum = this.baseFallMultiplyNum + 400 * jumpTime;
        multiplyNum = Math.min(multiplyNum, 13000);

        let velocityZ = (player.character.velocity.z * 1);
        multiplyNum = multiplyNum - velocityZ;

        player.character.addImpulse(Type.Vector.up.multiply(multiplyNum), true);
        // Console.error("[jumpTime]：" + jumpTime + "\n" + "[velocityZ]：" + velocityZ + "\n" + "[multiplyNum]：" + multiplyNum);
    }

    /**服务端的Update */
    private onUpdateS(dt: number): void {
        if (this.playerFlyAndFallMap.size > 0) {
            this.playerFlyAndFallMap.forEach((isFall, playerId) => {
                let player = Gameplay.getPlayer(playerId);
                this.isTouchDownS(player);
                this.updatePlayerStateS(playerId, isFall);
            });
        }
    }

    /**判断玩家是否落地（服务端） */
    private isTouchDownS(player: Gameplay.Player): void {
        if (player.character.isJumping) return;

        let playerPoint = new Type.Vector2(player.character.worldLocation.x, player.character.worldLocation.y)
        let isContainsPoint: boolean = false;
        for (let i = 0; i < this.ignoreAreaS.length; ++i) {
            if (this.ignoreAreaS[i].containsPoint(playerPoint)) {
                isContainsPoint = true;
                break;
            }
        }
        if (isContainsPoint) return;

        let playerId = player.getPlayerID();
        this.playTouchDownVFSAndSFXS(playerId);
        this.spreadToOthersS(playerId);
        this.initPlayerDataS(playerId);
        Console.error("[落地]");
    }

    /**更新此时飞行玩家的行为（服务端） */
    private updatePlayerStateS(playerId: number, isFall: boolean): void {
        let player = Gameplay.getPlayer(playerId);
        if (player.character.velocity.z <= 0 && isFall == true) {
            let animation = player.character.loadAnimation(TrampolineRescourse.Roll, true);
            animation.rate = animation.length / 0.4;
            animation.loop = 0;
            animation.play();
            this.playEffectS(playerId, this.playerFallEffects, TrampolineRescourse.SpinEffect, Gameplay.SlotType.Root,
                new Type.Vector(0, 0, 0), Type.Rotation.zero, new Type.Vector(2, 2, 2));
            this.playerFlyAndFallMap.set(playerId, false);
        }
        if (player.character.velocity.z > 0 && isFall == false) {
            let animation = player.character.loadAnimation(TrampolineRescourse.FlyUp, true);
            animation.rate = animation.length / 0.4;
            animation.loop = 0;
            animation.play();
            this.stopEffectS(playerId, this.playerFallEffects);
            this.playTailEffectS(playerId);
            this.playerFlyAndFallMap.set(playerId, true);
        }
    }

    /**播放触底音效和特效(服务端) */
    private playTouchDownVFSAndSFXS(playerId: number): void {
        let time = this.playersJumpTimeS.get(playerId);
        let effectId = time > 9 ? TrampolineRescourse.TrampolineN_bombFallsEffect : TrampolineRescourse.TrampolineStoneFallsEffect;
        let soundId = time > 9 ? TrampolineRescourse.TrampolineN_bombFallsSound : TrampolineRescourse.TrampolineStoneFallsSound;
        let scaleNum = Math.min(time * 0.2, 4);
        let effectScale = Type.Vector.one.multiply(scaleNum);

        let worldLocation = Gameplay.getPlayer(playerId).character.getWorldLocation();
        Service.EffectService.getInstance().playEffectAtLocation(effectId, worldLocation, 1,
            new Type.Rotation(0, 0, 0), effectScale);
        Service.SoundService.getInstance().play3DSound(soundId, worldLocation, 1, 1000);
    }

    /**玩家触底时波及其他人（服务端） */
    private spreadToOthersS(playerId: number): void {
        let groundPlayer = Gameplay.getPlayer(playerId);
        let time = this.playersJumpTimeS.get(playerId);
        let radius = this.playersImpactRadius.get(playerId);
        for (let player of Gameplay.getAllPlayers()) {
            if (groundPlayer == player) continue;

            let dis = Type.Vector.distance(player.character.worldLocation, groundPlayer.character.worldLocation)
            if (dis > radius) continue;

            let vec = player.character.worldLocation.clone().subtract(groundPlayer.character.worldLocation).normalize();
            vec = vec.add(Type.Vector.up).normalize();
            let multiplyNum = (1 - (dis / radius)) * (Math.min(this.baseMultiplyNum + time * 200, 6000));
            player.character.addImpulse(vec.clone().multiply(multiplyNum), true);
        }
    }

    /**初始化数据 */
    private initPlayerDataS(playerId: number): void {
        this.playerFlyAndFallMap.delete(playerId);
        this.playersJumpTimeS.delete(playerId);
        this.playersImpactRadius.delete(playerId);
        this.stopEffectS(playerId, this.playerFallEffects);
        this.stopTailEffectS(playerId);
        let player = Gameplay.getPlayer(playerId);
        player.character.stopAnimation(TrampolineRescourse.Roll);
        Events.dispatchToAllClient(ListenerEventsType.ServerToAllClient_HideRadiusUI, playerId);
        Events.dispatchToClient(Gameplay.getPlayer(playerId), ListenerEventsType.ServerToAllClient_HideJumpRecordUI);
    }

    /**播放特效（服务端） */
    private playEffectS(playerId: number, effectMap: Map<number, number>, effect: TrampolineRescourse, slotType: Gameplay.SlotType,
        offset?: Type.Vector, rotation?: Type.Rotation, scale?: Type.Vector): void {
        let player = Gameplay.getPlayer(playerId);
        if (effectMap.has(playerId)) {
            let effectId = effectMap.get(playerId);
            if (effectId) {
                Service.EffectService.getInstance().stopEffect(effectId);
            }
        }
        let playerEffectId = Service.EffectService.getInstance().playEffectOnPlayer(effect, player,
            slotType, 0, new Type.Vector(0, 0, -60), new Type.Rotation(new Type.Vector(0, -90, 0)), Type.Vector.one.multiply(3));
        effectMap.set(playerId, playerEffectId);
    }

    /**停止播放特效（服务端） */
    private stopEffectS(playerId: number, effectMap: Map<number, number>): void {
        if (effectMap.has(playerId)) {
            let effectId = effectMap.get(playerId);
            if (effectId) {
                Service.EffectService.getInstance().stopEffect(effectId);
                effectMap.set(playerId, null);
            }
        }
    }

    /**玩家悬空状态播放拖尾特效(服务端) */
    private playTailEffectS(playerId: number): void {
        if (this.playerTailEffectMap.has(playerId)) return;
        let player = Gameplay.getPlayer(playerId);
        let tailEffectLeftFoot = Service.EffectService.getInstance().playEffectOnPlayer(
            TrampolineRescourse.TrampolineEffect, player, Gameplay.SlotType.LeftFoot, 0);
        let tailEffectRightFoot = Service.EffectService.getInstance().playEffectOnPlayer(
            TrampolineRescourse.TrampolineEffect, player, Gameplay.SlotType.RightFoot, 0);
        this.playerTailEffectMap.set(playerId, [tailEffectLeftFoot, tailEffectRightFoot]);
    }

    /**玩家触底后停止播放拖尾特效（服务端） */
    private stopTailEffectS(playerId: number): void {
        if (!this.playerTailEffectMap.has(playerId)) return;
        let tailEffect = this.playerTailEffectMap.get(playerId);
        for (let i = 0; i < tailEffect.length; ++i) {
            Service.EffectService.getInstance().stopEffect(tailEffect[i]);
        }
        this.playerTailEffectMap.delete(playerId);
    }
    /**------------------------------------------- 服务端 ------------------------------------------------ */

    /**------------------------------------------- 通用 ------------------------------------------------ */

    /**
     * 震荡函数
     * @param x 
     * @param speed 震荡衰减/增益的速度
     * @param frequency 震荡的频率
     * @param amplitude 震荡的幅度
     * @returns 
     */
    private shakeFunc(x: number, speed: number, frequency: number, amplitude: number): number {
        return (Math.pow(speed, -x) * Math.sin(2 * frequency * Math.PI * x)) / amplitude;
    }

    /**资源下载 */
    public async downloadRes(guid: string): Promise<boolean> {
        if (Util.AssetUtil.isAssetExist(guid)) {
            return true;
        }
        return await Util.AssetUtil.asyncDownloadAsset(guid);
    }
}

export class OBB {
    center: Type.Vector2
    nx: Type.Vector2
    ny: Type.Vector2
    extents_x: number
    extents_y: number

    constructor(center: Type.Vector2, axisX: Type.Vector2, axisY: Type.Vector2, extentsX: number, extentsY: number) {
        this.center = center
        this.nx = axisX
        this.ny = axisY
        this.extents_x = extentsX
        this.extents_y = extentsY
    }

    containsPoint(point: Type.Vector2): boolean {
        let c2p = point.clone().subtract(this.center)
        let xBenchmark = Math.abs(this.dotV2(this.nx, this.nx.clone().multiply(this.extents_x)))
        let xTentative = Math.abs(this.dotV2(c2p, this.nx))
        if (xTentative >= xBenchmark) {
            return false
        }
        let yBenchmark = Math.abs(this.dotV2(this.ny, this.ny.clone().multiply(this.extents_y)))
        let yTentative = Math.abs(this.dotV2(c2p, this.ny))
        return yTentative < yBenchmark;
    }

    private dotV2(a: Type.Vector2, b: Type.Vector2) {
        return a.x * b.x + a.y * b.y
    }
}
/**客户端&服务端发送的事件类型 */
export enum ListenerEventsType {
    /**服务端发给所有客户端（模型震动） */
    ServerToAllClient_Shake = "ServerToAllClient_Shake",
    /**服务端发给所有客户端（显示落点UI） */
    ServerToAllClient_ShowRadiusUI = "ServerToAllClient_ShowRadiusUI",
    /**服务端发给所有客户端（隐藏落点UI） */
    ServerToAllClient_HideRadiusUI = "ServerToAllClient_HideRadiusUI",
    /**服务端发给指定客户端（显示JumpRecordUI） */
    ServerToAllClient_ShowJumpRecordUI = "ServerToAllClient_ShowJumpRecordUI",
    /**服务端发给所有客户端（隐藏JumpRecordUI） */
    ServerToAllClient_HideJumpRecordUI = "ServerToAllClient_HideJumpRecordUI",
}

export enum TrampolineRescourse {
    /**蹦床拖尾特效 */
    TrampolineEffect = "27392",
    /**蹦床石头落地特效 */
    TrampolineStoneFallsEffect = "57200",
    /**蹦床核弹落地特效 */
    TrampolineN_bombFallsEffect = "85150",
    /**玩家空中降落漩涡特效 */
    SpinEffect = "7833",
    /**----------------------------------------- */
    /**蹦床音效 */
    TrampolineSound = "14182",
    /**蹦床石头落地音效 */
    TrampolineStoneFallsSound = "27862",
    /**蹦床核弹落地音效 */
    TrampolineN_bombFallsSound = "39343",
    /**----------------------------------------- */
    /**蹦床上升动画 */
    FlyUp = "35401",
    /**翻滚下落动画 */
    Roll = "14736",
}
