﻿import Console from "../../../../../Tools/Console";
import { Utils } from "../../../../../Tools/utils";
import { GameConfig } from "../../../../../config/GameConfig";
import { TelegraphPoleConfig } from "../../../../../config/TelegraphPole";
import GlobalData from "../../../../../const/GlobalData";

@Core.Class
export default class TelegraphPole extends Core.Script {
    /**-------------------- 可控数据 -------------------- */
    @Core.Property({ group: "属性", displayName: "预加载资源", onChangedInEditor: "onPreloadAssetsChangedInEditor" })
    private preloadAssets = "";

    @Core.Property({ displayName: "被电时间（s）", group: "电线杆属性" })
    private delayDieTime: number = 3;
    /**-------------------- 可控数据 -------------------- */

    /**-------------------- 属性 -------------------- */
    /**当前客户端玩家 */
    private player: Gameplay.Player = null;
    /**-------------------- 属性 -------------------- */

    /**-------------------- 数据 -------------------- */
    /**播放动画的唯一标识 */
    private playerAnimationMap: Map<number, Gameplay.Animation> = new Map<number, Gameplay.Animation>();;
    /**播放音效的唯一标识 */
    private playerAudioMapId: Map<number, number> = new Map<number, number>();
    /**播放特效的唯一标识 */
    private playerEffectMapId: Map<number, number> = new Map<number, number>();
    /**延迟死亡的唯一标识 */
    private delayDieTimeoutMap: Map<number, number> = new Map<number, number>();
    /**延迟复活的唯一标识 */
    private delayRebornTimeout: number = null;
    /**-------------------- 数据 -------------------- */

    /** 当脚本被实例后，会在第一帧更新前调用此函数 */
    protected onStart(): void {
        if (Util.SystemUtil.isClient()) {
            Console.error("TelegraphPole-onStart-isClient");
            this.initDataC();
            this.bindTriggerC();
            this.bindEventsC();
        }
        if (Util.SystemUtil.isServer()) {
            Console.error("TelegraphPole-onStart-isServer");
            this.bindEventsS();
        }
    }

    /** 当预加载资源改动的时候自动调用此函数 */
    public onPreloadAssetsChangedInEditor() {
        let assets: string = ""

        for (let key in TelegraphPoleResource) {
            let keyToAny: any = key;
            if (isNaN(keyToAny)) {
                let telegraphPoleResource: any = TelegraphPoleResource[key];
                let telegraphPoleResourceEnum: TelegraphPoleResource = telegraphPoleResource;
                assets = assets + telegraphPoleResourceEnum + ",";
            }
        }
        assets = assets.substring(0, assets.length - 1);
        this.preloadAssets = assets;
    }
    /**------------------------------------------- 客户端 ------------------------------------------------ */
    private telegraphPole: TelegraphPoleConfig = null;
    private telegraphPoleLen: number = 0;
    /**初始化数据 */
    private async initDataC(): Promise<void> {
        this.telegraphPole = GameConfig.TelegraphPole;
        this.telegraphPoleLen = this.telegraphPole.getAllElement().length;
        this.player = await Gameplay.asyncGetCurrentPlayer();
    }

    /**绑定触发器(客户端) */
    private async bindTriggerC(): Promise<void> {
        if (this.telegraphPoleLen == 0) return;
        for (let i = 0; i < this.telegraphPoleLen; ++i) {
            let trigger = (await Core.GameObject.asyncFind(this.telegraphPole.getElement(i + 1).TriggerGuid)) as Gameplay.Trigger;
            trigger.onEnter.add((char: Gameplay.Character) => {
                this.onEnterTriggerC(char);
            });
        }
    }

    /**绑定事件(客户端) */
    private bindEventsC(): void {
        Events.addServerListener(ListenerEventType.SendClient, this.endElectrocutedC.bind(this));
    }

    /**进入触发器（客户端） */
    private onEnterTriggerC(char: Gameplay.Character): void {
        Console.error("[hkz]");
        if (char != Gameplay.getCurrentPlayer().character) return;
        Console.error("[hkz1]");
        this.startElectrocutedC();
        Events.dispatchLocal("dianji", 1);
    }

    /**开始电刑（客户端） */
    private async startElectrocutedC(): Promise<void> {
        this.setPlayerStateC(false);
        Events.dispatchToServer(ListenerEventType.SendServers);
    }

    /**结束电刑-开始死亡（客户端） */
    private endElectrocutedC(): void {
        //开启布娃娃效果
        this.player.character.ragdollEnable = true;
        if (this.delayRebornTimeout) {
            clearTimeout(this.delayRebornTimeout);
        }
        this.delayRebornTimeout = setTimeout(() => {
            clearTimeout(this.delayRebornTimeout);
            this.rebornC();
        }, this.delayDieTime / 2 * 1000);
    }
    /**复活（客户端） */
    private rebornC(): void {
        let index = Utils.getRandomInteger(0, 3);
        this.player.character.worldLocation = GlobalData.homeLocs[index];
        this.player.character.worldRotation = GlobalData.homeRots[index];
        //关闭布娃娃效果
        this.player.character.ragdollEnable = false;
        this.setPlayerStateC(true);
    }
    /**设置人物状态（客户端） */
    private setPlayerStateC(v: boolean) {
        this.player.character.jumpEnable = v;
        this.player.character.moveEnable = v;
    }
    /**------------------------------------------- 客户端 ------------------------------------------------ */

    /**------------------------------------------- 服务端 ------------------------------------------------ */
    /**绑定事件（服务端） */
    private bindEventsS(): void {
        Events.addClientListener(ListenerEventType.SendServers, this.startElectrocutedS.bind(this));
    }
    /**开始电刑（服务端） */
    private async startElectrocutedS(player: Gameplay.Player): Promise<void> {
        let playerid = player.getPlayerID();

        if (this.playerAnimationMap.has(playerid)) {
            let animationId = this.playerAnimationMap.get(playerid);
            if (animationId) {
                animationId.stop();
            }
        }
        let playerAnimationId = player.character.playAnimation(TelegraphPoleResource.Animation, 0, 2);
        this.playerAnimationMap.set(playerid, playerAnimationId);

        if (this.playerAudioMapId.has(playerid)) {
            let audioId = this.playerAudioMapId.get(playerid);
            if (audioId) {
                Service.SoundService.getInstance().stop3DSound(audioId);
            }
        }
        let playerAudioId = Service.SoundService.getInstance().play3DSound(TelegraphPoleResource.Audio, player.character.getWorldLocation(), 0, 1);
        this.playerAudioMapId.set(playerid, playerAudioId);

        if (this.playerEffectMapId.has(playerid)) {
            let effectId = this.playerEffectMapId.get(playerid);
            if (effectId) {
                Service.EffectService.getInstance().stopEffect(effectId);
            }
        }
        let playerEffectId = Service.EffectService.getInstance().playEffectOnPlayer(TelegraphPoleResource.Hurt, player,
            Gameplay.SlotType.Root, 0, new Type.Vector(0, 0, 0), Type.Rotation.zero, new Type.Vector(1, 1, 0.35));
        this.playerEffectMapId.set(playerid, playerEffectId);

        if (this.delayDieTimeoutMap.has(playerid)) {
            let dieId = this.delayDieTimeoutMap.get(playerid);
            if (dieId) {
                clearTimeout(dieId);
            }
        }
        let delayDieTimeoutId = setTimeout(() => {
            if (this.delayDieTimeoutMap.has(playerid)) {
                let dieId = this.delayDieTimeoutMap.get(playerid);
                if (dieId) {
                    clearTimeout(dieId);
                }
                else {
                    clearTimeout(delayDieTimeoutId);
                }
            }
            else {
                clearTimeout(delayDieTimeoutId);
            }
            this.endElectrocutedS(playerid);
        }, this.delayDieTime * 1000);

        this.delayDieTimeoutMap.set(playerid, delayDieTimeoutId);
    }

    /**结束电刑-开始死亡（服务端） */
    private endElectrocutedS(playerid: number): void {
        if (this.playerAnimationMap.has(playerid)) {
            let animationId = this.playerAnimationMap.get(playerid);
            if (animationId) {
                animationId.stop();
                this.playerAnimationMap.set(playerid, null);
            }
        }

        if (this.playerAudioMapId.has(playerid)) {
            let audioId = this.playerAudioMapId.get(playerid);
            if (audioId) {
                Service.SoundService.getInstance().stop3DSound(audioId);
                this.playerAudioMapId.set(playerid, null);
            }
        }

        if (this.playerEffectMapId.has(playerid)) {
            let effectId = this.playerEffectMapId.get(playerid);
            if (effectId) {
                Service.EffectService.getInstance().stopEffect(effectId);
                this.playerEffectMapId.set(playerid, null);
            }
        }
        //开启布娃娃效果
        Events.dispatchToClient(Gameplay.getPlayer(playerid), ListenerEventType.SendClient);
    }
    /**------------------------------------------- 服务端 ------------------------------------------------ */
}

export enum TelegraphPoleResource {
    /**触电动画 */
    Animation = "14698",
    /**触电音效 */
    Audio = "20464",
    /**被电特效 */
    Hurt = "7806",
}

/**监听事件的类型 */
export enum ListenerEventType {
    /**客户端发给服务端同步玩家表现 */
    SendServers = "SendServers_TelegraphPole",
    /**服务端发给客户端同步玩家表现 */
    SendClient = "SendClient_TelegraphPole",
}