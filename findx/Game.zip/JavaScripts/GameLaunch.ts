﻿import Console from "./Tools/Console";
import { GameConfig } from "./config/GameConfig";
import GlobalData from "./const/GlobalData";
import AchievementData from "./module/AchievementModule/AchievementData";
import AchievementModuleC from "./module/AchievementModule/AchievementModuleC";
import AchievementModuleS from "./module/AchievementModule/AchievementModuleS";
import AdsModuleC from "./module/AdsModule/AdsModuleC";
import AdsModuleS from "./module/AdsModule/AdsModuleS";
import CollectionData from "./module/CollectionMOdule/CollectionData";
import CollectionModuleC from "./module/CollectionMOdule/CollectionModuleC";
import CollectionModuleS from "./module/CollectionMOdule/CollectionModuleS";
import { DanceModuleC, DanceModuleS } from "./module/DanceModule";
import HUDDate from "./module/HUDModule/HUDDate";
import HUDModuleC from "./module/HUDModule/HUDModuleC";
import HUDModuleS from "./module/HUDModule/HUDModuleS";
import { PetData, PetModuleC, PetModuleS } from "./module/PetModule/PetModule";
import { PlayerLevelData, PlayerModuleC, PlayerModuleS } from "./module/PlayerModule/PlayerModule";
import RankingModuleC from "./module/RankingModule/RankingModuleC";
import RankingModuleS from "./module/RankingModule/RankingModuleS";
import ShopData from "./module/ShopModule/ShopData";
import ShopModuleC from "./module/ShopModule/ShopModuleC";
import ShopModuleS from "./module/ShopModule/ShopModuleS";
import SignInData from "./module/SignInModule/SignInData";
import SignInModuleC from "./module/SignInModule/SignInModuleC";
import SignInModuleS from "./module/SignInModule/SignInModuleS";

@Core.Class
export default class GameLaunch extends Core.Script {
    @Core.Property({ displayName: "是否发布到手机", group: "脚本设置" })
    private isOnline: boolean = true;

    @Core.Property({ displayName: "是否隐藏头顶UI", group: "脚本设置" })
    private isHideHeadUI: boolean = true;

    @Core.Property({ displayName: "是否开启IAA", group: "脚本设置" })
    private isOpenIAA: boolean = true;

    @Core.Property({ displayName: "是否开启测试UI", group: "脚本设置" })
    private isOpenTest: boolean = false;

    @Core.Property({ displayName: "Log级别", group: "脚本设置", selectOptions: { "None": "0", "Log": "1", "Warn": "2", "Error": "3" } })
    private logLevel: string = "0";

    @Core.Property({ group: "全局设置", displayName: "预加载资源", onChangedInEditor: "onPreloadAssetsChangedInEditor" })
    private preloadAssets = "";

    /** 当脚本被实例后，会在第一帧更新前调用此函数 */
    protected onStart(): void {
        this.onStartCS();
        if (Util.SystemUtil.isClient()) {
            this.onStartC();
        }
        else if (Util.SystemUtil.isServer()) {
            this.onStartS();
        }
    }

    /**客户端服务端的onStart */
    private onStartCS(): void {
        this.useUpdate = true;
        this.onRegisterModule();
        GlobalData.isDebug = !this.isOnline;
        GlobalData.logLevel = Number(this.logLevel);
        GlobalData.isHideHeadUI = this.isHideHeadUI;
        GlobalData.isOpenIAA = this.isOpenIAA;
        GlobalData.isOpenTest = this.isOpenTest;
    }

    /**
     * 周期函数 每帧执行
     * 此函数执行需要将this.useUpdate赋值为true
     * @param dt 当前帧与上一帧的延迟 / 秒
     */
    protected onUpdate(dt: number): void {
        Util.TweenUtil.TWEEN.update();
        if (Util.SystemUtil.isClient()) {
            this.onUpdateC(dt);
        }
        else if (Util.SystemUtil.isServer()) {
            this.onUpdateS(dt);
        }
    }

    /**注册模块 */
    private onRegisterModule(): void {
        ModuleManager.getInstance().registerModule(HUDModuleS, HUDModuleC, HUDDate);
        ModuleManager.getInstance().registerModule(RankingModuleS, RankingModuleC, null);
        ModuleManager.getInstance().registerModule(ShopModuleS, ShopModuleC, ShopData);
        ModuleManager.getInstance().registerModule(CollectionModuleS, CollectionModuleC, CollectionData);
        ModuleManager.getInstance().registerModule(SignInModuleS, SignInModuleC, SignInData);
        ModuleManager.getInstance().registerModule(AdsModuleS, AdsModuleC, null);
        ModuleManager.getInstance().registerModule(PetModuleS, PetModuleC, PetData);
        ModuleManager.getInstance().registerModule(AchievementModuleS, AchievementModuleC, AchievementData);
        ModuleManager.getInstance().registerModule(DanceModuleS, DanceModuleC, null);
        ModuleManager.getInstance().registerModule(PlayerModuleS, PlayerModuleC, PlayerLevelData);
    }

    /** 当预加载资源改动的时候自动调用此函数 */
    public onPreloadAssetsChangedInEditor(): void {
        let assets: string = "";
        GameConfig.Clothes.getAllElement().forEach((cloth, index, arr) => {
            if (!cloth.ClothGuid) return;
            assets = assets + cloth.ClothGuid + ",";
            assets = assets + cloth.Icon + ",";
        });
        GameConfig.Assets.getAllElement().forEach((asset, index, arr) => {
            if (!asset.Guid) return;
            if (index < (arr.length - 1)) {
                assets = assets + asset.Guid + ",";
            } else {
                assets = assets + asset.Guid;
            }
        });
        this.preloadAssets = assets;
    }

    /**------------------------------------------- 客户端 ------------------------------------------------ */
    /**客户端的OnStart */
    private onStartC(): void {

    }

    /**客户端的update */
    private onUpdateC(dt: number): void {

    }

    /**------------------------------------------- 客户端 ------------------------------------------------ */

    /**------------------------------------------- 服务端 ------------------------------------------------ */
    /**服务端的OnStart */
    private onStartS(): void {
        DataStorage.setTemporaryStorage(!this.isOnline);
    }

    /**服务端的update */
    private onUpdateS(dt: number): void {

    }
    /**------------------------------------------- 服务端 ------------------------------------------------ */
}